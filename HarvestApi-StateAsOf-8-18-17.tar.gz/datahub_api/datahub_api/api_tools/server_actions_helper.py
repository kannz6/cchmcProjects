import requests

from enum import Enum
from datahub_api.api_tools.common_responses import Phrases


def appendChar(_strng,_char):
	_line = "{0}\n{1}".format(_strng,_char)
	for i in range(len(_strng)-1):
		_line += "{0}".format(_char)
	return _line

def appendCharInt(_i,_char):
	_line = "{0}".format(_char)
	for i in range(_i):
		_line += "{0}".format(_char)
	return _line

class Action(Enum):
	exit_the_api = -4
	no_value_found = -3
	server_request_failed = -2
	cancel_action = -1
	success = 0
	update_the_filter_with_your_query = 1
	clear_the_filters = 2
	save_your_new_filter = 3
	export_your_data = 4
	Public_Queries = 5
	load_a_public_query = 6
	Saved_Queries = 7
	load_a_saved_query = 8
	print_all_field_values = 9
	save_your_query = 10
	enter_a_description_for_your_query = 11
	add_users_to_your_query = 12
	make_your_query_public = 13
	display_available_queries = 14
	load_a_query  = 15
	query_data = 16
	create_another_filter = 17
	remove_a_filter = 18
	add_columns_to_the_view_before_exporting_your_data = 19
	remove_columns_to_the_view_before_exporting_your_data = 20
	add_a_message_for_users_who_have_access_to_your_query = 21

	display_data_client_documentation = 22

	
class UserWantsTo:
	def do(action):
		try:
			i = [ 2 if Action(action).value >= 10 else 1 ]
		except Exception as _passing_name:
			try:
				i = [ 2 if action >= 10 else 1 ]
			except Exception as _no_enum_found:
				sys.exit("No enum found for {0}".format(_no_enum_found))

		_user_response = input("{0} {1} [y/n]: ".format(Phrases.questions[2],Action(action).name.replace("_", " ")))

		if "y" not in _user_response:
			return False
		else:
			return True

	def display(**kwargs):
		if not kwargs:
			_user_response = ""
			_user_response = input("{0}: ".format(Phrases.questions[0]))
			
			if _user_response in Phrases.public:			
				print("\n{0}\n".format(appendChar(Action(5).name.replace("_", " "),"-")))
				return Action.load_a_public_query
			elif _user_response in Phrases.saved:
				print("\n{0}\n".format(appendChar(Action(7).name.replace("_", " "),"-")))
				return Action.load_a_saved_query
			elif _user_response in Phrases.quit_api:
				return Action.exit_the_api

		elif kwargs:
			if "saved" in kwargs['item']:
				print("\n{0}\n".format(appendChar(Action(7).name.replace("_", " "),"-")))

