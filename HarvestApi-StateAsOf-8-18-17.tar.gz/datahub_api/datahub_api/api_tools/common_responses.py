#Class to make handling random user responses to different input prompts more robust

class Phrases:
	
	positive_responses = ['yes', 'y', 'Y', 'YES', 'Yes']
	negative_responses = ['no', 'No', 'n', 'N', 'NO']
	cancel_current_action = ['back', 'cancel', 'exit']
	quit_api = ['quit']
    
	csv_operators = ['is neither','is either']
	equality_operators = ['is greater than', 'is less than', 'is greater than or equal to', 'is less than or equal to']
	positive_regex_query_operators = ['is', 'is either', 'matches', 'contains the text']
	negative_regex_query_operators = ['is not', 'is neither', 'does not match', 'does not contain the text', 'is not between']
	range_operators = ['is between', 'is not between']

	public = ['public', 'public queries', 'Public Queries', 'PUBLIC QUERIES']
	saved = ['saved', 'saved queries', 'Saved Queries', 'SAVED QUERIES']

	questions = ['\nWould you like to see public queries or your saved queries', '\nAre you sure you want to', '\nWould you like to']
	
	def show_escape_options(self):
		return 'You may enter [back/quit/cancel]'

class Categories:

	groups = ['Subject', 'Sample', 'Variants', 'Demographics', 'Diagnoses', 'Genomics', 'Extracardiac', 'Outcomes <= 1 year',
	'Outcomes > 1 year', 'Procedures', 'Genetic Testing', 'Other']
	groups_with_sections = ['Sample', 'Demographics', 'Diagnoses', 'Genomics', 'Extracardiac', 'Procedures', 'Genetic Testing']