from requests_oauthlib import OAuth2Session
from oauthlib.oauth2 import LegacyApplicationClient
from coreapi import Client, transports
import requests
from hal_codec import HALCodec
from coreapi.transports.http import HTTPTransport

class datahub_client:
    def __init__(self, client_id, client_secret, datahub_url):
        self.client_id = client_id
        self.client_secret = client_secret
        self.datahub_url = datahub_url  
        self.token = None

    def connect(self, username, password):
        oauth_client = LegacyApplicationClient(client_id=self.client_id)
        oauth = OAuth2Session(client=oauth_client)
        token_url = self.datahub_url + '/o/token/'
        self.token = oauth.fetch_token(token_url=token_url, username=username, password=password, client_id=self.client_id, client_secret=self.client_secret, scope='read')
        self.headers={'Authorization': 'Bearer ' + self.token['access_token']}
        codec = HALCodec()
        url = self.datahub_url + '/api/'

        # document = datahub_client.get(self.datahub_url + '/api/')
        response = requests.get(url, headers=self.headers)
        self.doc = codec.load(response.content)

    def get_stored_token(self):
        return self.token

    def __getattr__(self, attr):
        # return self.doc[attr]
        return self.follow(attr)

    def links(self):
        return self.doc.links

    def follow(self,attr):
        transport = [HTTPTransport(headers=self.headers)]
        client = Client(transports=transport)
        data = client.action(self.doc, [attr])
        return data

    