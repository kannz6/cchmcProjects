import io
import json
import os
import re
import readline
import requests
import sys, traceback
import time
import urllib.request

from datahub_api.api_tools.common_responses import Phrases, Categories
from datahub_api.api_tools.server_actions_helper import Action, UserWantsTo, appendChar, appendCharInt

from collections import OrderedDict
from coreapi import Client, transports, Document
from coreapi.transports.http import HTTPTransport
from enum import Enum
from hal_codec import HALCodec
from io import IOBase,BytesIO
from oauthlib.oauth2 import LegacyApplicationClient
from requests_oauthlib import OAuth2Session
from requests import Session, Request


class datahub_client:
    def __init__(self, client_id, client_secret, datahub_url):
        self.client_id = client_id
        self.client_secret = client_secret
        self.datahub_url = datahub_url  
        self.token = None
        self.api_keys = None
        self.concepts = None
        self.current_concept_id = None
        self.current_concept_name = None
        self.current_field_id = []
        self.current_field_values = {}
        self.current_field_operators = {}
        self.current_field_name = {}
        # self.current_field_searchable = {}
        self.supported_data_export_types = {}
        self.current_concept_simple_type = {}
        self.current_export_column_cids = None
        self.buffer_size = 2**17
        self.variant_ids = []

    def connect(self, username, password):
        """

        description: 

            method for initializing the api session.

        sets:

            self.username
            self.password
            self.headers
            self.token
            self.doc

        """
        oauth_client = LegacyApplicationClient(client_id=self.client_id)
        oauth = OAuth2Session(client=oauth_client)
        token_url = self.datahub_url + '/o/token/'
        self.username = username;self.password = password

        #added this to bypass the oauth2 error requiring https
        # http://stackoverflow.com/questions/27785375/testing-flask-oauthlib-locally-without-https
        os.environ['OAUTHLIB_INSECURE_TRANSPORT'] = '1'

        self.token = oauth.fetch_token(token_url=token_url, username=username, password=password, client_id=self.client_id, client_secret=self.client_secret, scope=['read','write'])
        self.headers={'Authorization': 'Bearer ' + self.token['access_token']}
        codec = HALCodec()
        url = self.datahub_url + '/api/'
        _get_api_home_items = {"type":"get","url":url,"h":self.headers}
        self.doc = codec.load(self.requestResource(**_get_api_home_items).content)
        self.set_api_keys()
        self.toggle_query(oauth)
        self.set_concepts()
        if not self.get_current_export_columns_in_view():
            sys.exit("Issue getting view! Exiting for debug.")

    def get_stored_token(self): 
        """

        description: 

            getter for oauth token set during connect

        """
        return self.token

    def __getattr__(self, attr): return self.follow(attr)
        
    def links(self): 
        """
        description: 

            method for getting the accessible links in the api doc

        """
        return self.doc.links

    def follow(self,attr):
        """

        description: 

            method for getting the resources of an attribute

        returns:

            the resources associated with the passed attribute of the document.

        """
        transport = [HTTPTransport(headers=self.headers)]
        client = Client(transports=transport)
        data = client.action(self.doc, [attr])
        return data

    def get_concepts(self, **kwargs):
        """

        associated api url:

            http://bmipcgcd1.chmcres.cchmc.org/api/concepts/
            http://bmipcgcd1.chmcres.cchmc.org/api/fields/
        
        description: 

            Method for accessing specific key,value pairs in the api concepts json object.
            queryable Categories

        required kwargs:
            
            "ret" : [ "json" | "index" | "status" | "field" ]

        optional kwargs:

            "cid" : concept id of desired json object to access

            "name" : name of the concept to be returned

            "fields-dict" : dictionary containing the keys of a concepts field to use when "ret" is set to "field". calls get_fields

        returns:

            if "ret" set to "field" - operators of a field associated with a concept, the value of a specific link associated
            with a field json object, or the values of a specific field associated with a concept. 

            if "ret" set to "index" - the index of the concept in the concepts json object.

            if "ret" set to "json" - the entire json object can be returned if a concept name or id is provided, or the entire concepts json object.

            if "ret" set to "status" - the status of the most recent request to http://bmipcgcd1.chmcres.cchmc.org/api/concepts/

        """
        if not kwargs: return self.concepts
        else:
            if "ret" in kwargs.keys():
                if "json" in kwargs['ret']:
                    if "name" in kwargs.keys():
                        i = self.get_index_of_concepts_dictionary(**{"name":kwargs['name']})
                        return self.concepts.json()[i]
                    elif "cid" in kwargs.keys():
                        i = self.get_index_of_concepts_dictionary(**{"cid":kwargs['cid']})
                        return self.concepts.json()[i]
                    else:
                        return self.concepts.json()
                elif "index" in kwargs['ret']:
                    if "name" not in kwargs.keys() and "cid" not in kwargs.keys():
                        sys.exit("Bad index into concepts attempt! Safe exit")
                    else:
                        if "name" in kwargs.keys():
                            i = [ self.concepts.json().index(v) for v in self.concepts.json() if v['name'] == kwargs['name'] ]
                        elif "cid" in kwargs.keys():
                            i = [ self.concepts.json().index(v) for v in self.concepts.json() if v['id'] == kwargs['cid'] ]
                        return i[0]
                elif "status" in kwargs['ret']:
                    return self.concepts.status_code
                elif "field" in kwargs['ret']:
                    if "name" not in kwargs.keys() and "cid" not in kwargs.keys():
                        sys.exit("Bad index into concepts attempt! Safe exit")
                    else:
                        _get_field_items = {"type":"get"}
                        if "name" in kwargs.keys():
                            i = self.get_index_of_concepts_dictionary(**{"name":kwargs['name']})
                        elif "cid" in kwargs.keys():
                            i = self.get_index_of_concepts_dictionary(**{"cid":kwargs['cid']})

                        _get_field_items.update({"url":self.concepts.json()[i]['_links']['fields']['href']})
                        _get_field_request = self.requestResource(**_get_field_items)

                        if _get_field_request.status_code == requests.codes.ok:

                            _fields_items = {"field-response":_get_field_request,"items":kwargs['fields-dict']}
                            return self.get_fields(**_fields_items)
                        else:
                            return Action.server_request_failed

    def get_fields(self,**kwargs):
        """

        associated api url:

            http://bmipcgcd1.chmcres.cchmc.org/api/fields/
        
        description: 

            Method for accessing specific key,value pairs of a concepts field json object.

        required kwargs:
            
            "field-response" : response object containing the json object(s) of the fields associated with a concept. request made in get_concepts.

            "items" : [ "field-id" | "field-json-key" | "field-name" ]

        kwargs combinations:

            "field-id" : id of the json object to be accesed associated with a concept.        

            and 

            "field-json-key" :  [ "link" | "operators" ]

            or 

            "field-name" : name of the field json object associated with a concept.

            and

            "field-json-key" :  [ "id" | "link" | "operators" | "values" | "searchable" ]

            "logic" : boolean value to trigger conditional statement that returns the correct operators to return. 

        returns:

            if "ret" set to "field" - operators of a field associated with a concept, the link (as a string) of a field associated
            with a field json object (distribution, stats, values), or the values of a specific field associated with a concept. 

        """
        if not kwargs: sys.exit("Bad fields request!")
        else:
            if "field-response" not in kwargs.keys(): sys.exit("No 'field-response' kwarg found in dictionary!")
            elif "items" not in kwargs.keys() or kwargs['items'] is None: sys.exit("Either no 'items' kwarg found in dictionary, or the value is null!")

            elif "field-id" in kwargs['items'].keys():
                j = [ kwargs['field-response'].json().index(x) for x in kwargs['field-response'].json() if x['id'] ==  kwargs['items']['field-id'] ]
                j = j.pop() 
                if "operators" in kwargs['items']['field-json-key']:
                    _field_ops = [ x[1] for x in kwargs['field-response'].json()[j]['operators'] ]
                    return _field_ops
                elif "link" in  kwargs['items']['field-json-key']:
                    return kwargs['field-response'].json()[j]['_links'][kwargs['items']['link']]['href']
                elif "searchable" in kwargs['items']['field-json-key']:
                    return kwargs['field-response'].json()[j]['searchable']
            elif "field-name" in kwargs['items'].keys():
                j = [ kwargs['field-response'].json().index(x) for x in kwargs['field-response'].json() if x['name'] == kwargs['items']['field-name'] ]
                j = j.pop() 
                if "id" in kwargs['items']['field-json-key']:
                    return kwargs['field-response'].json()[j]['id'] 
                elif "operators" in kwargs['items']['field-json-key']:
                    if "logic" in kwargs['items'].keys() and kwargs['items']['logic'] is True:
                        _field_ops = [ x for x in kwargs['field-response'].json()[j]['operators'] if ( x[1] in Phrases.equality_operators and "e" in x[0] ) or x[1] in Phrases.range_operators ]
                    else:
                        _field_ops = [ x for x in kwargs['field-response'].json()[j]['operators'] if x[1] in Phrases.positive_regex_query_operators or x[1] in Phrases.negative_regex_query_operators ]
                    return _field_ops
                elif "link" in kwargs['items']['field-json-key']:
                    return kwargs['field-response'].json()[j]['_links'][kwargs['items']['link']]['href']
                elif "values" in kwargs['items']['field-json-key']:
                    if "boolean" not in kwargs['field-response'].json()[j]['simple_type']:
                        _get_field_values_items = {"type":"get","url": kwargs['field-response'].json()[j]['_links']['values']['href'],"p":{'limit':0}}
                    else:
                        _get_field_values_items = {"type":"get","url": kwargs['field-response'].json()[j]['_links']['values']['href']}
                    
                    _get_field_values_request = self.requestResource(**_get_field_values_items)
                    if _get_field_values_request.status_code == requests.codes.ok:
                        if len(_get_field_values_request.json()['values']) == 1:
                            if "None" in _get_field_values_request.json()['values'][0]['label']:
                                return Action.no_value_found
                        return _get_field_values_request.json()['values']
                    else:
                        sys.exit("Failed trying to get values for {0}. Safe exit with status: {1}.".format(kwargs['field-name'],Action.server_request_failed))
                elif "searchable" in kwargs['items']['field-json-key']:
                    return kwargs['field-response'].json()[j]['searchable']
            else:
                if "id" in kwargs['items']['field-json-key']:
                    return kwargs['field-response'].json()[0]['id'] 
                elif "operators" in kwargs['items']['field-json-key']:
                    return kwargs['field-response'].json()[0]['operators']
                elif "link" in kwargs['items']['field-json-key']:
                    return kwargs['field-response'].json()[0]['_links'][kwargs['items']['link']]['href']
                sys.exit("** Field request failed with status: {0} **".format(Action.server_request_failed))

    def get_supported_data_export_types(self):
        """
        ###############
        #B2BASSINET-223
        ###############

        Note: need to refactor this method to just update the supported data types IF there is a change 

        associated api url:

            http://bmipcgcd1.chmcres.cchmc.org/api/data/export/

        description: 

            method for setting the supported formats to export data in

        sets:

            self.supported_data_export_types

        """
        _api_home_links = self.get_api_keys()['_links']
        test_supported_data_export_types = {}
        try:
            _get_request_items = {"type":"get","url":_api_home_links['exporter']['href']}
            supported_data_export_types_request = self.requestResource(**_get_request_items)
            if supported_data_export_types_request.status_code == requests.codes.ok:
                local_vals_dict = supported_data_export_types_request.json()['_links']
                [ [ self.supported_data_export_types.update({ x : v }) for k,v in local_vals_dict[x].items() if "href" in k and "self" not in x and v not in self.supported_data_export_types.values() ] for x in local_vals_dict ]
                # print("Supported data export types: {0}".format(self.supported_data_export_types))
            else:
                print("Supported data export types request status: {0}, reason: {1}".format(supported_data_export_types_request.status_code, supported_data_export_types_request.reason))
                sys.exit("[get_supported_data_export_types] Exiting with status: {0}".format(Action.server_request_failed))
        except Exception as _bad_export_href_request:
            print("*[get_supported_data_export_types] Exception: {0}*\n".format(_bad_export_href_request))
            sys.exit("Safe exit.\n")

    def export_data(self):
        """
        ###############
        #B2BASSINET-223
        ###############

        Note: may want to consider giving user ability to specify file name because currently, the timestamp is the only way to differentiate
        between files.

        associated api url:

            http://bmipcgcd1.chmcres.cchmc.org/api/data/export/

        description: 

            method for download of heartsmart data

        returns:

            data file in format specified by user saved under

        """
        self.get_supported_data_export_types();#1
        
        if not self.get_current_export_columns_in_view():
            print("\nIssue retrieving current columns set for export!\n")
            return Action.server_request_failed
        
        _update_columns = input("Do you want to add or remove a specific column to the data that will be exported [add/remove/n]: ")

        if "add" in _update_columns:           
            if self.add_column_to_view_for_export() != Action.success:
                return Action.add_columns_to_the_view_before_exporting_your_data
        elif "remove" in _update_columns:
            if self.remove_column_from_view_for_export() != Action.success:
                return Action.remove_columns_to_the_view_before_exporting_your_data
        elif _update_columns in Phrases.cancel_current_action:
            return Action.cancel_action
        elif _update_columns in Phrases.quit_api:
            sys.exit("\nGoodbye!\n")
        elif _update_columns in Phrases.negative_responses:
            print("\n{0}".format(appendChar("Current columns set for export:", "-")))
            [ self.print_concept_name(_concept_fid) for _concept_fid in self.current_export_column_cids ]

        print("\n{0}".format(appendChar("Supported data export types:", "-")))
        [ print("{0}".format(k)) for k in self.supported_data_export_types.keys() ]

        _export_type = input("\nWhat format would you like to export your data in: ")
        if _export_type in Phrases.cancel_current_action:
            return Action.cancel_action
        elif _export_type in Phrases.quit_api:
            sys.exit("\nGoodbye!\n")

        if _export_type in self.supported_data_export_types.keys():#2possible refactor here?
            _number_of_pages_to_export = input("\nEnter the number of pages to export (i.e., 1, 1...3, or all): ")
            if _number_of_pages_to_export in Phrases.cancel_current_action:
                return Action.cancel_action
            elif _number_of_pages_to_export in Phrases.quit_api:
                sys.exit("\nGoodbye!\n")
            elif "all" in _number_of_pages_to_export:
                _export_url = "{0}".format(self.supported_data_export_types.get(_export_type))
            elif "." in _number_of_pages_to_export or "-" in _number_of_pages_to_export:
                if "-" in _number_of_pages_to_export:
                    x = _number_of_pages_to_export.split("-") 
                else:
                    x = _number_of_pages_to_export.split(".")

                _url_set = False                  
                if len(x) != 2:
                    _number_of_pages_to_export = "all"
                    _export_url = "{0}".format(self.supported_data_export_types.get(_export_type))
                    _url_set = True
                elif "..." not in _number_of_pages_to_export or int(_number_of_pages_to_export[0]) > 1:
                    if "-" in _number_of_pages_to_export:
                        _number_of_pages_to_export.replace("-", "...")
                    elif _number_of_pages_to_export.count(".") != 3:
                        _number_of_pages_to_export = x[0] + "..." + x[1]

                    if int(x[0]) != 1:
                        if "." not in _number_of_pages_to_export[len(_number_of_pages_to_export) -1]:
                            _number_of_pages_to_export = "1..." + x[1]
                        else:
                            _number_of_pages_to_export = "1"
                    else:
                        if "." not in _number_of_pages_to_export[len(_number_of_pages_to_export) -1]:
                            _number_of_pages_to_export = "1..." + x[1]
                        else:
                            _number_of_pages_to_export = "1"
                if not _url_set:
                    _export_url = "{0}{1}/".format(self.supported_data_export_types.get(_export_type),_number_of_pages_to_export)           
            elif isinstance(int(_number_of_pages_to_export),int) and len(_number_of_pages_to_export) == 1 and int(_number_of_pages_to_export) >= 1:
                if int(_number_of_pages_to_export) > 1:
                    _number_of_pages_to_export = "1..." + _number_of_pages_to_export
                _export_url = "{0}{1}/".format(self.supported_data_export_types.get(_export_type),_number_of_pages_to_export)
            else:
                print("You must enter a valid number of pages to export your data!")
                return Action.export_your_data
        else:
            return Action.export_your_data
            # print("{0}".format(_export_url))

        _x = len("attachment; filename=") + 1

        try:
            _columns_from_variants = [ x for x in self.current_export_column_cids if x in self.variant_ids ]
            if len(_columns_from_variants) != 0:
                self.buffer_size = 2**21
            # print("colums from variants to be exported: {0}\nbuffer size: {1}".format(_columns_from_variants, self.buffer_size))
            r = requests.get(_export_url,headers=self.headers,stream=True,timeout=None)
            # _buffer_size2 = 2**17
            # _buffer_size3 = 2**18
            ############################################################################################################################# 
            #saving for test example to be stored in commit history for reference if needed.
            # r2 = requests.get(_export_url ,headers=self.headers,stream=True)
            # r3 = requests.get(_export_url ,headers=self.headers,stream=True)
            # r4 = requests.get(_export_url ,headers=self.headers,stream=True)
            # r5 = requests.get(_export_url ,headers=self.headers,stream=True)
            t0 = time.clock()
            ############################################################################################################################# 
            if r.status_code == requests.codes.ok:
                local_filename = r.headers['Content-Disposition'][_x:-1].replace(" ","_")
                print(local_filename); print(r.status_code);              
                starttime = time.time() - t0
                try:
                    # _columns_from_variants = [x for x in self.current_export_column_cids if x in self.show_query_sub_Categories(**{"category":"Variants","action":"return"}) ]
                    # sys.exit("{0}".format(self.show_query_sub_Categories(**{"category":"Variants","action":"return"})))
                    with open(local_filename, 'wb') as fd: [fd.write(chunk) for chunk in r.iter_content(chunk_size=self.buffer_size)]
                except Exception as _incomplete_file_read:
                    sys.exit("[export_data] Exception during stream: {0}".format(_incomplete_file_read))
                endtime = time.time() - t0
                print ("download time {0} chunk size: {1} s\n".format(self.buffer_size,endtime-starttime))
                ############################################################################################################################# 
                #saving for test example to be stored in commit history for reference if needed.
                # if r2.status_code == requests.codes.ok:
                #     starttime1 = time.time() -t0
                #     with open(local_filename + "_2", 'wb') as fd: [fd.write(chunk) for chunk in r2.iter_content(chunk_size=_buffer_size2)]                        
                #     endtime1 = time.time() -t0
                #     print ("download time {0} chunk size: {1} s\n".format(_buffer_size2,endtime1-starttime1))
                    
                # if r3.status_code == requests.codes.ok:
                #     starttime2 = time.time() -t0
                #     with open(local_filename + "_3", 'wb') as fd: [fd.write(chunk) for chunk in r3.iter_content(chunk_size=_buffer_size3)]                        
                #     endtime2 = time.time() -t0
                #     print ("download time {0} chunk size: {1} s\n".format(_buffer_size3,endtime2-starttime2))

                    # if r3.status_code == requests.codes.ok:
                    #     starttime3= time.time() -t0
                    #     with open(local_filename+ "_3", 'wb') as fd: [fd.write(chunk) for chunk in r3.iter_content(chunk_size=_buffer_size3)]                        
                    #     endtime3 = time.time() -t0
                    #     print ("download time {0} chunk size: {1} s\n".format(_buffer_size3,endtime3-starttime3))

                #         if r4.status_code == requests.codes.ok:
                #             starttime4= time.time() -t0
                #             print ("start time 32768: {0}".format(time.time() - t0))
                #             with open(local_filename+ "_4", 'wb') as fd: [fd.write(chunk) for chunk in r4.iter_content(chunk_size=32768)]                        
                #             endtime4 = time.time() -t0
                #             print ("end time 32768: {0}\n{1} s\n".format(time.time() - t0, endtime4-starttime4 ))

                #             if r5.status_code == requests.codes.ok:
                #                 starttime5 = time.time() -t0 
                #                 print ("start time 65536: {0}".format(time.time()- t0))
                #                 with open(local_filename+ "_5", 'wb') as fd: [fd.write(chunk) for chunk in r5.iter_content(chunk_size=65536)]                        
                #                 endtime5 = time.time() -t0
                #                 print ("end time 65536: {0}\n{1} s\n".format(time.time() - t0, endtime5-starttime5 ))
                                # sys.exit()
                ##############################################################################################################################
                return Action.success
            else:
                print("[Export Data]: Status Code- {0}\nReason: {1}\nmethod return status: {2}".format(r.status_code,r.reason,Action.server_request_failed))
                return Action.server_request_failed
        except Exception as _bad_export_data_request:
            print("*[export_data] Exception: {0}*".format(_bad_export_data_request))

    def set_api_keys(self):
        """

        associated api url:

            http://bmipcgcd1.chmcres.cchmc.org/api/

        description: 

            setter for api json object. See show_group_labels for example usage.

        sets:

            self.api_keys

        """
        _api_url = self.datahub_url + '/api/'; r = self.requestResource(**{"type":"get","url":_api_url,"h":self.headers})
        if r.status_code == requests.codes.ok:
            self.api_keys = r.json()
        else:
            sys.exit("[set_api_keys] Exiting with status: {0}".format(Action.server_request_failed))

    def get_api_keys(self): 
        """

        associated api url:

            http://bmipcgcd1.chmcres.cchmc.org/api/

        description: 

            getter for api json object. See show_group_labels for example usage.

        returns:

            self.api_keys

        """
        return self.api_keys

    def show_group_labels(self):
        """
        ###############
        #B2BASSINET-144
        ###############

        associated api url:

            http://bmipcgcd1.chmcres.cchmc.org/api/concepts/

        description: 

            Method that displays only the main category groups of the heartsmart api. See get_filters for example usage.

        """
        print("\n")
        [ print("{0}".format(appendChar(g,"-"))) for g in Categories.groups ]

    def show_query_sub_Categories(self,**kwargs):
        """
        ###############
        #B2BASSINET-144
        ###############

        associated api url:

            http://bmipcgcd1.chmcres.cchmc.org/api/concepts/

        description: 

            Method for organizing the nested structure of concepts and the fields associated with the different
            queryable Categories

        required kwargs:

            "category" : parent concept 'name' value 

            "action" : [ "return" | "show" ]

        optional kwargs:

            "sub-category" : name of the category associated with a parent group. 

            "filter" : name of the specific field that has a parent category and a sub-category, used when "return" is the action

            "sections" : boolean kwarg used only if "action" set to "show" which when set to True will not print the names of the
                         fields that have a parent concept. This allows for more organized navigation of the queryable concepts/fields.

        returns:

            list of queryable filters available to be used to build a query IF the "action" is set to "return", prints the matched concepts/fields
            if "action" is set to "show"

        """
        if kwargs and "category" in kwargs.keys() and "action" in kwargs.keys():
            _category = kwargs['category']; _returning_sub_category = False; _printing_sub_category = False
            if "sub-category" in kwargs.keys():
                _sub_category = kwargs['sub-category']
                if "return" in kwargs['action']:
                    _returning_sub_category = True
                    if "filter" in kwargs.keys():
                        _filter = kwargs['filter']
                elif "show" in kwargs['action']:
                    _printing_sub_category = True
            try:
                if self.get_concepts(**{"ret": "status"}) == requests.codes.ok:
                    try:
                        if "Other" not in _category:
                            _queryable_concepts_w_category = [ k for k in self.get_concepts(**{"ret": "json"}) if k['queryable'] and k['category'] is not None ]
                            _concept_category_names = [ k['name'] for k in _queryable_concepts_w_category if k['category']['parent'] is None and k['category']['name'] == _category ]
                            if "show" in kwargs['action']:
                                _show = [ {"category": k['category']['name'],"name":k['name'],"cid":k['id']} for k in _queryable_concepts_w_category if k['category']['parent'] is not None and ( k['category']['parent']['name'] == _category or k['category']['name'] == _category ) ]
                                if _printing_sub_category:
                                    _show = [ k for k in _show if k['category'] == _sub_category]
                                if len(_concept_category_names) > len(_show):
                                    print("{0}".format(appendChar(_category,"-")))
                                    [ print("\t{0}".format(_concept_name)) for _concept_name in _concept_category_names ]
                                elif len(_show) > len(_concept_category_names):
                                    print("{0}".format(appendChar(_category,"-")))
                                    _sub_category_names = set([ _concept['category'] for _concept in _show ])
                                    for _category_name in _sub_category_names:
                                        print("\t{0}".format(_category_name))
                                        if "sections" in kwargs.keys() and not kwargs['sections']:
                                            [ print("\t\t{0}".format(_concept['name'])) for _concept in _show if _concept['category'] == _category_name ]
                            elif "return" in kwargs['action']:
                                _category_sub_category_dict = {}
                                # if not _returning_sub_category:#6-14-17
                                _ret = [ {"category": k['category']['name'],"name":k['name'],"cid":k['id']} for k in _queryable_concepts_w_category if k['category']['parent'] is not None and ( k['category']['parent']['name'] == _category or k['category']['name'] == _category ) ]
                                # else:#6-14-17
                                if _returning_sub_category:#6-14-17
                                    _ret = [ k for k in _ret if k['category'] == _sub_category]
                                    if "filter" in kwargs.keys():
                                        _ret = [ {"name":k['name'],"cid":k['cid']} for k in _ret if k['name'] == _filter ]
                                    elif len(_ret) == 0:
                                        _ret = [ {"name":k['name'],"cid":k['id']} for k in _queryable_concepts_w_category if ( k['category']['parent'] is None and k['category']['name'] == _category and k['name'] == _sub_category ) or ( k['category']['parent'] is not None and k['category']['parent']['name'] == _category and k['name'] == _sub_category )  ]
                                    # sys.exit("\nreturning: {0}".format(_ret))
                                    return _ret
                                # print("{0}\n{1}".format(_ret,_concept_category_names))
                                if len(_concept_category_names) > len(_ret):
                                    return _concept_category_names
                                elif len(_ret) > len(_concept_category_names):
                                    # print("{0}".format(appendChar(_category,"-")))
                                    _sub_category_names = set([ _concept['category'] for _concept in _ret ])
                                    for _category_name in _sub_category_names:
                                        _sub_Categories_list = []
                                        [ _sub_Categories_list.append(_concept['name']) for _concept in _ret if _concept['category'] == _category_name and _concept['name'] not in _sub_Categories_list ]
                                        _category_sub_category_dict.update({_category_name:_sub_Categories_list})
                                    return _category_sub_category_dict
                        elif "Other" in _category:
                            try:
                                _queryable_concepts_w_o_category = [ k for k in self.get_concepts(**{"ret": "json"}) if k['queryable'] and not k['category'] ] 
                                _queryable_concept_names_w_o_category = [ k['name'] for k in _queryable_concepts_w_o_category ]
                                if "show" in kwargs['action']:
                                    print("{0}".format(appendChar('Other',"-")))
                                    [ print("\t{0}".format(_concept_name)) for _concept_name in _queryable_concept_names_w_o_category ]
                                elif "return" in kwargs['action']:
                                    if not _returning_sub_category:
                                        _queryable_concept_names_w_o_category = [ k['name'] for k in _queryable_concepts_w_o_category ]
                                    else:
                                        _queryable_concept_names_w_o_category = [ k['name'] for k in _queryable_concepts_w_o_category if k['name'] == _sub_category ]
                                    # print("(elif Other) ret: {0}".format(_queryable_concept_names_w_o_category))
                                    return _queryable_concept_names_w_o_category

                            except Exception as _none_type_object:
                                print("*[show_query_sub_Categories (double nested (inside elif) try)] Exception: {0}*\n".format(_none_type_object))
                                sys.exit("Safe exit.")
                    except Exception as _bad_list_attempt:
                        print("*[show_query_sub_Categories (nested try)] Exception: {0}*\n".format(_bad_list_attempt))
                        sys.exit("Safe exit.")
            except Exception as argument:
                print("*[show_query_sub_Categories] Exception: {0}*\n".format(argument))
                sys.exit("Safe exit.\n")
        else:
            sys.exit("show_query_sub_Categories requires an input dictionary")

    def get_index_of_concepts_dictionary(self,**kwargs):
        """

        Note: this method can be used to de-couple get_concepts() or can be removed and replaced by calls to get_concepts() with the
        proper kwargs.

        description: 

            Method for getting the index of a specific concept json object

        required kwargs:

            "name" : concept name

            or

            "cid" : concept id

        returns:

            index of concept json object if found, Action.no_value_found otherwise

        """
        try:
            if not kwargs:
                sys.exit("Must provide argument dictionary to use the method get_index_of_concepts_dictionary!")
            else:
                if "name" in kwargs.keys():
                    return self.get_concepts(**{"ret": "index", "name":kwargs['name']})
                elif "cid" in kwargs.keys():
                    return self.get_concepts(**{"ret": "index", "cid":kwargs['cid']})
        except Exception as _bad_index:
            print("get_index_of_concepts_dictionary for: {0} failed!".format(_bad_index) )
            return Action.no_value_found

    def print_concept_name(self,cid): 
        """

        description: 

            Method for organized display of concept json object
        
        required args:
            
            "cid" : concept id

        """
        print("{0}".format(self.get_concepts(**{"ret": "json", "cid":cid})['name']))

    def set_current_field_values(self, f):
        """

        description: 

            Method for setting the current_concept/field containers being used in build_query
        
        required args:


        sets:

            self.current_concept_simple_type
            self.current_field_id
            self.current_field_name
            self.current_field_operators

        """
        try:
            self.current_field_id.append(f['id'])
            if "float" in f['internal_type'] or "number" in f['simple_type']:
                _range_ops = [ e for e in f['operators'] if e[1] in Phrases.range_operators or e[1] in Phrases.equality_operators ]
                _range_ops = [ x for x in _range_ops  if len(x) != 0 ]
                self.current_field_operators.update({ f['id'] : _range_ops})
            else:
                _ops = []; [ _ops.append(x[1]) for x in f['operators'] if x[1] not in _ops ];
                self.current_field_operators.update({ f['id'] : _ops }) 
                # self.current_field_operators.update({ f['id'] : f['operators']})
            self.current_concept_simple_type.update({ f['id']: f['simple_type'] })            
            self.current_field_name.update({ f['id'] : f['name']})

        except Exception as argumentN:
            print("*[set_current_field_values] Exception: {0}\n*\n".format(argumentN))
            sys.exit("Safe exit.\n")

    def get_query_values(self,**kwargs):
        """
        
        Note: this method can be used to de-couple get_concepts(). it can also take advantage of get_concepts() using
        "field-name" or "field-id" for increased performance where currently self.get_field_dictionary_by_concept() is used.

        description: 

            Method for organized display of concept json object
        
        required kwargs:

            "name" : count as provided by enumerate

            or 

            "cid" : field id stored in self.current_field_id

        calls:

            self.set_current_field_values()

        """
        if not kwargs or ("name" not in kwargs.keys() and "cid" not in kwargs.keys()):
            sys.exit("Must provide argument dictionary to use the method get_query_values with either 'name' or 'cid' kwarg!")
        else:
            if "name" in kwargs.keys():
                _field_as_json_obj = self.get_field_dictionary_by_concept(**{"name":kwargs['name']})
            elif "cid" in kwargs.keys():
                _field_as_json_obj = self.get_field_dictionary_by_concept(**{"cid":kwargs['cid']})
            try:
                _get_request_items = {"type":"get","url":_field_as_json_obj['_links']['fields']['href']}
                r_fields = self.requestResource(**_get_request_items)
                if r_fields.status_code == requests.codes.ok:
                    [ self.set_current_field_values(f) for f in r_fields.json() ]
                else:
                    sys.exit("[get_query_values] Exiting with status: {0}".format(Action.server_request_failed))
            except Exception as argument:
                print("*[get_query_values] Exception: {0}*\n".format(argument))
                sys.exit("Safe exit.\n")
                
    def print_element_operators_neatly(self,e):
        """

        description: 

            Method for organized display of concept json object operators
        
        required args:

            "e" : field id stored in self.current_field_id

        """
        for c,o in enumerate(self.current_field_operators.get(e)):
            if( c < (len(self.current_field_operators.get(e))-1)):
                if isinstance(o,list):
                    print("{0}".format(o[1]), end=", ")
                else:
                    print("{0}".format(o), end=", ")
            else:
                if isinstance(o,list):
                    print("{0}".format(o[1]), end=" ")
                else:
                    print("{0}".format(o), end=" ")
    
    def print_element_values(self,e):
        """

        description: 

            Method for organized display of concept json object values
        
        required args:

            "e" : field id stored in self.current_field_id

        """
        if UserWantsTo.do(Action.print_all_field_values):
            print("\"values\":")
            [ print("{0}".format(x['label']), end=", ") if c < len(e) - 1 and "None" not in e[c+1]['label'] else print("{0}".format(x['label']), end=" ") for c,x in enumerate(e) if x['value'] is not None ]

    def dump_current_concept_wrapper(self,**kwargs):
        """

        description: 

            Method for organized display of concept json object
        
        required kwargs:

            "l" : count as provided by enumerate
            "e" : field id stored in self.current_field_id

        """
        if not kwargs:
            sys.exit("You must supply 'l' and 'e' kwargs to use this method.")
        else:
            _l = kwargs['l']; _e = kwargs['e']
            if len(self.current_field_id) > 1:
                print("[# {0}]\n\n\"concept\" : {1} ({2})\n".format(_l+1,self.current_concept_name, self.current_concept_id))
            print("[\"field\" : {0}] name: {1}\n".format(_e,self.current_field_name.get(_e)))
            print("\"operators\":")
            self.print_element_operators_neatly(_e)

            print("\n")
            if _l <= (len(self.current_field_id)-2) and (len(self.current_field_id) > 1):
                print("\n{0}".format(appendCharInt(len("\"concept\" : {0}".format(self.current_concept_name)),"_")))
            elif _l == (len(self.current_field_id)-1) and (len(self.current_field_id) > 1):
                print("\n\n")

    def build_query(self, **kwargs):
        """
        ###############
        #B2BASSINET-146
        #B2BASSINET-248
        ###############

        description: 

            Method for building a natural language data filter to be added to the context

        returns:

            Action.success if there are no values associated with a filter being used to build a query.
          
        """
        _query = "Query Builder:\nFormat: {0} [operator] [value]".format(self.current_concept_name)
        print("\n{0}".format(appendChar("Current Index:","-"),self.current_concept_name))
        _local_vals_dict = {}
        
        [ self.dump_current_concept_wrapper(**{"l":l,"e":e}) for l,e in enumerate(self.current_field_id) ]
        
        print("\n\n{0}".format(_query))
        _operator = input("\nEnter the operator: ")
        _range_logic = False
        _equality_logic = False
###################################################
        _get_concepts_dict = {"ret":"field"}
###################################################
        if _operator in Phrases.cancel_current_action:
            return Action.cancel_action
        elif _operator in Phrases.range_operators:
            _operator_logic_language = "and"
            _range_logic = True
        elif _operator in Phrases.equality_operators:
            _equality_logic = True
        else:
            _operator_logic_language = "or"

        _query = ""
        _input_values = []
        _val_list = []
        _fid_list = []
        _op_list = []
        _language_list = {}

        if len(self.current_field_id) > 1:
            _more = True
            _loop_count = 0

            _field = input("\n\nEnter the field: ")
###################################################
            _get_concepts_dict.update({"name":self.current_concept_name,"fields-dict":{"field-json-key":"id","field-name":_field}})
            _fid = self.get_concepts(**_get_concepts_dict)
###################################################
            while _more:

                if _range_logic:

                    if _loop_count == 0:
                        print ("\n[{0}] {1}: ".format(_fid,self.current_field_name.get(_fid)))
                        _get_concepts_dict.update({"fields-dict":{"field-json-key":"values","field-name":_field}})
                        _field_vals = self.get_concepts(**_get_concepts_dict)
                        if _field_vals == Action.no_value_found:
                            print("There are no values associated with this filter!")
                            self.reset_instance_containers_for_new_query()
                            return Action.success
                        else:
                            self.print_element_values(_field_vals)

                        _values = input("\n\nEnter the first value: ")                    
                        while not self.user_input_okay(**{"check":{"single-entry":str(_values)}}):
                            _values = ""; _values = input("\n\nEnter a valid first value: ")                    
                        _query += "{0} {1} {2}".format(_field,_operator,_values)
                        _input_values.append(str(_values))
                        _loop_count = _loop_count + 1

                        _sub_query = "{0} {1} ".format(_field,_operator)
                        if _fid not in _language_list.keys():#fid is not in the language list dictionary, key is unique
                            _language_list.update({ _fid : _sub_query + ";"+ _values })

                    elif _loop_count == 1:
                        _values = input("\n\nEnter the 2nd value: ")                    
                        while not self.user_input_okay(**{"check":{"single-entry":str(_values)}}):
                            _values = ""; _values = input("\n\nEnter a valid second value: ")                    
                        
                        if str(_values) in _input_values:
                            while _input_values.count(str(_values)) != 0 :
                                _values = input("\nEnter a unique second value(s): ")

                        while not self.user_input_okay(**{"check":{"range-values":{"lower-bound":_input_values[0],"upper-bound":str(_values)}}}):
                            _values = ""; _values = input("\n\nUpper bound cannot be less than lower bound: ")

                        _input_values.append(str(_values))
                        _query += " {0} {1}".format(_operator_logic_language,_values)
                        _loop_count = _loop_count + 1

                        _sub_query = "{0} ".format(_operator_logic_language)
                        if _fid in _language_list.keys():#key already exists, need to append the values
                            _existing_entry = _language_list.get(_fid)#first get the existing entry
                            _language_list.update({ _fid : _existing_entry + ";" + _sub_query + ";"+_values })#then append the new subquery and the values

                    if _fid not in _fid_list:
                        _fid_list.append(_fid)
                
                elif _equality_logic:
                    print ("\n[{0}] {1}: ".format(_fid,self.current_field_name.get(_fid)))
                    _get_concepts_dict.update({"fields-dict":{"field-json-key":"values","field-name":_field}})
                    _field_vals = self.get_concepts(**_get_concepts_dict)
                    # [ print("{0}".format(x['label']), end=", ") if c < len(_equality_vals) - 1 else print("{0}".format(x['label']), end=" ") for c,x in enumerate(_equality_vals) if x['value'] is not None ]
                    if _field_vals == Action.no_value_found:
                        print("There are no values associated with this filter!")
                        self.reset_instance_containers_for_new_query()
                        return Action.success
                    else:
                        self.print_element_values(_field_vals)

                    _values = input("\n\nEnter the value: ")
                    while not self.user_input_okay(**{"check":{"single-entry":str(_values)}}):
                        _values = ""; _values = input("\n\nEnter a valid value: ")
                    _query += "{0} {1} {2}".format(_field,_operator,_values)                    

                    _sub_query = "{0} {1} ".format(_field,_operator)
                    
                    if _fid not in _language_list.keys():#fid is not in the language list dictionary, key is unique
                        _language_list.update({ _fid : _sub_query + ";"+ _values })
                    elif _fid in _language_list.keys():#key already exists, need to append the values
                        _existing_entry = _language_list.get(_fid)#first get the existing entry
                        _language_list.update({ _fid : _existing_entry + ";" + _sub_query + ";"+_values })#then append the new subquery and the values

                    if _fid not in _fid_list:
                        _fid_list.append(_fid)

                    _input_values.append(str(_values))
                    _loop_count = _loop_count + 1
                else:
                    if _loop_count == 0:
                        _get_concepts_dict.update({"name":self.current_concept_name,"fields-dict":{"field-json-key":"operators","field-name":_field}})
                    else:
                        _field = input("\n\nEnter the field: ")
                        _get_concepts_dict.update({"fields-dict":{"field-json-key":"id","field-name":_field}})
                        _fid = self.get_concepts(**_get_concepts_dict)
                        _get_concepts_dict.update({"fields-dict":{"field-json-key":"operators","field-name":_field}})

                    [ _op_list.append(_valid_op) for _valid_op in self.get_concepts(**_get_concepts_dict) if _valid_op not in _op_list ]

                    if _loop_count == 0:
                        _original_ops = _op_list
                    elif _loop_count > 0:
                        if len(_original_ops) != len(_op_list):
                            disjoint = [ x[1] for x in _op_list if x not in _op_list ]
                            mismatched_types = [ "True" if y in Phrases.range_operators or y in Phrases.equality_operators else "False" for y in disjoint ]
                            if "True" in mismatched_types:
                                print("Mismatching operators with the field you entered and the query you are building... you will have to build another query from scratch after you finish building your current query")
                                _more = False;
                                break

                    print ("\n[{0}] {1}: ".format(_fid,self.current_field_name.get(_fid)))
                    _get_concepts_dict.update({"fields-dict":{"field-json-key":"values","field-name":_field}})
                    _field_vals = self.get_concepts(**_get_concepts_dict)
                    if _field_vals == Action.no_value_found:
                        print("There are no values associated with this filter!")
                        self.reset_instance_containers_for_new_query()
                        return Action.success
                    else:
                        self.print_element_values(_field_vals)

                    _values = input("\n\nEnter the value (or enter 'as csv' to enter a comma seperated list of values): ")
                    # _values = input("\n\nEnter the value(s): ")#comment out 8-7-17
                    ##########################################################################################################
                    if "as csv" not in _values:
                        _sub_query = "{0} {1} {2}".format(self.current_concept_name,_field,_operator)#comment out 7-26-17

                        if _fid not in _language_list.keys():#fid is not in the language list dictionary, key is unique
                            _language_list.update({ _fid : _sub_query + ";"+_values })
                        elif _fid in _language_list.keys():#key already exists, need to append the values
                            _existing_entry = _language_list.get(_fid)#first get the existing entry                        
                            _language_list.update({ _fid : _existing_entry + ";" + _sub_query + ";"+_values })#then append the new subquery and the values

                        if _loop_count == 0:
                            _query += "{0} {1} {2}".format(self.current_concept_name,_operator,_values)

                            if _fid not in _fid_list:
                                _fid_list.append(_fid)
                                _loop_count = _loop_count + 1
                        else:
                            _query += " {0} {1} {2} {3} {4}".format(_operator_logic_language,self.current_concept_name,_field,_operator,_values)
                            if _fid not in _fid_list:
                                _fid_list.append(_fid)

                        _input_values.append(str(_values))
                    ##########################################################################################################
                    #8-7-17
                    #add else
                    else:
                        # if _loop_count != 0:
                        #     _sub_query = "{0} {1} {2}".format(self.current_concept_name,_field,_operator)#comment out 7-26-17
                        # else:
                        #     _sub_query = "{0} {1} {2}".format(self.current_concept_name,_field,_operator)#comment out 7-26-17
                        if _loop_count == 0:
                            if _operator in Phrases.negative_regex_query_operators: 
                                _query += "{0} {1} {2}".format(self.current_concept_name,Phrases.csv_operators[0],_values)
                                _sub_query = "{0} {1} {2}".format(self.current_concept_name,Phrases.csv_operators[0],_values)
                            else:
                                _query += "{0} {1} {2}".format(self.current_concept_name,Phrases.csv_operators[1],_values)
                                _sub_query = "{0} {1} {2}".format(self.current_concept_name,Phrases.csv_operators[1],_values)
                            
                            _loop_count = _loop_count + 1                        
                        else:
                            if len(_input_values) != 0:
                                _unique_values = [v for v in x if str(v) not in _input_values ]
                                # sys.exit("len: {0}\nunique vals: {1}\n".format(len(_unique_values),_unique_values))
                            if len(_unique_values) != 0:
                                _append_query_with_previous_inputs = ", ".join(_unique_values[0:len(_unique_values)-1])
                                
                                if _operator in Phrases.negative_regex_query_operators:
                                    _query = "{0} {1} {2} {3}".format(self.current_concept_name,Phrases.csv_operators[0],_values,_append_query_with_previous_inputs)
                                    # _sub_query = "{0} {1} {2} {3}".format(self.current_concept_name,Phrases.csv_operators[0],_values,_append_query_with_previous_inputs)
                                else:
                                    _query = "{0} {1} {2} {3}".format(self.current_concept_name,Phrases.csv_operators[1],_values,_append_query_with_previous_inputs)
                                    # _sub_query = "{0} {1} {2} {3}".format(self.current_concept_name,Phrases.csv_operators[1],_values,_append_query_with_previous_inputs)
                                _sub_query = "{0} {1} {2}".format(self.current_concept_name,_field,_operator)#comment out 7-26-17                       
                        
                        if _fid not in _fid_list:
                            _fid_list.append(_fid)

                        _values=""; _values = input("\n\nEnter the list of values (seperated by commas): ") 
                        _unique_values = []; _unique_values_str = ""; y = []; _tmp_list = []; _unique_values_list = [];
                        x = _values.split(", ")   

                        if _fid not in _language_list.keys():#fid is not in the language list dictionary, key is unique
                            [ _tmp_list.append(_sub_query + ";"+ v + ";" ) if c < len(x)-1 else _tmp_list.append(_sub_query + ";"+ v ) for c,v in enumerate(x) ]
                            _tmp_list = "".join(_tmp_list)
                            # _language_list.update({ _fid : _sub_query + ";"+_values })
                            _language_list.update({ _fid : _tmp_list })

                        elif _fid in _language_list.keys():#key already exists, need to append the values
                            
                            _existing_entry = _language_list.get(_fid)#first get the existing entry
                            y = _existing_entry.split(";")[1]

                            if len(_input_values) != 0:
                                _unique_values = [v for v in x if str(v) not in _input_values and str(v) not in y ]
                                # _unique_values_str = "{0};".format(_fid).join(_unique_values)#need to join string with sub_queries individually
                                [ _tmp_list.append(_sub_query + ";"+ uv +";") if c < len(_unique_values)-1 else _tmp_list.append(_sub_query + ";"+ uv ) for c,uv in enumerate(_unique_values) ]
                                _tmp_list = "".join(_tmp_list)
                                _language_list.update({ _fid : _existing_entry + ";" + _tmp_list })#then append the new subquery and the values
                            # sys.exit("y: {0}\nu-v: {1}\nll: {2}".format(y,_unique_values_str,_language_list))
                        # if _loop_count == 0:
                        #     if _operator in Phrases.negative_regex_query_operators: 
                        #         _query += "{0} {1} {2}".format(self.current_concept_name,Phrases.csv_operators[0],_values)
                        #     else:
                        #         _query += "{0} {1} {2}".format(self.current_concept_name,Phrases.csv_operators[1],_values)
                            
                        #     if _fid not in _fid_list:
                        #         _fid_list.append(_fid)

                        #     _loop_count = _loop_count + 1                        
                        # else:
                        #     # if len(_input_values) != 0:
                        #     #     _unique_values = [v for v in x if str(v) not in _input_values ]
                        #         # sys.exit("len: {0}\nunique vals: {1}\n".format(len(_unique_values),_unique_values))
                        #     if len(_unique_values) != 0:
                        #         _append_query_with_previous_inputs = ", ".join(_unique_values[0:len(_unique_values)-1])
                                
                        #         if _operator in Phrases.negative_regex_query_operators:
                        #             _query = "{0} {1} {2} {3}".format(self.current_concept_name,Phrases.csv_operators[0],_values,_append_query_with_previous_inputs)
                        #         else:
                        #             _query = "{0} {1} {2} {3}".format(self.current_concept_name,Phrases.csv_operators[1],_values,_append_query_with_previous_inputs)
                       
                        #     if _fid not in _fid_list:
                        #         _fid_list.append(_fid)

                        [ _input_values.append(str(e)) for e in x if e not in _input_values ]
                    ##########################################################################################################
                    #comment out 8-7-17
                    # if _fid not in _language_list.keys():#fid is not in the language list dictionary, key is unique
                    #     _language_list.update({ _fid : _sub_query + ";"+_values })
                    # elif _fid in _language_list.keys():#key already exists, need to append the values
                    #     _existing_entry = _language_list.get(_fid)#first get the existing entry                        
                    #     _language_list.update({ _fid : _existing_entry + ";" + _sub_query + ";"+_values })#then append the new subquery and the values

                    # if _loop_count == 0:
                    #     _query += "{0} {1} {2}".format(self.current_concept_name,_operator,_values)

                    #     if _fid not in _fid_list:
                    #         _fid_list.append(_fid)
                    #         _loop_count = _loop_count + 1
                    # else:
                    #     _query += " {0} {1} {2} {3} {4}".format(_operator_logic_language,self.current_concept_name,_field,_operator,_values)
                    #     if _fid not in _fid_list:
                    #         _fid_list.append(_fid)

                    # _input_values.append(str(_values))

                ############################################################################################################################################
                [ _val_list.append({"label": x['label'], "value" : x['value']}) for x in _field_vals if x['label'] in _input_values and x['value'] is not None and {"label":x['label'],"value":x['value']} not in _val_list ]
                # print("\n\n******[test vals list comprehension]******: {0}\n\n".format(_val_list))
                ############################################################################################################################################           
                
                if _range_logic:
                    if _loop_count == 2:#we are dealing with a logical 'and' statement, only need two values
                        _get_concepts_dict.update({"fields-dict":{"logic":True,"field-json-key":"operators","field-name":_field}})
                        _op_list = self.get_concepts(**_get_concepts_dict); _more = False; _values = "";
                    else:
                        _values = ""; continue
                elif _equality_logic:
                    _get_concepts_dict.update({"fields-dict":{"logic":True,"field-json-key":"operators","field-name":_field}})
                    _op_list = self.get_concepts(**_get_concepts_dict)
                    _more = False; break
                else :
                    _another_field = input("\nEnter another field [y/n]: ")
                
                    if _another_field in Phrases.cancel_current_action:
                        _more = False; _values = ""; self.reset_instance_containers_for_new_query()
                        return -1
                    elif _another_field in Phrases.quit_api:
                        _more = False; sys.exit("\nGoodbye!\n")
                    elif _another_field not in Phrases.positive_responses:
                        _more = False
                    else:
                        _field = ""; _fid = None; _values = "";
        else:
            _field = self.current_field_name.get(self.current_field_id[0])
            if kwargs is not None and "lookup-concept-by" in kwargs.keys():
                if "cid" in kwargs['lookup-concept-by'].keys():
                    _get_concepts_dict.update({"cid":kwargs['lookup-concept-by']['cid'],"fields-dict":{"field-json-key":"id","field-name":_field}})
                elif "name" in kwargs['lookup-concept-by'].keys():
                    _get_concepts_dict.update({"name":kwargs['lookup-concept-by']['name'],"fields-dict":{"field-json-key":"id","field-name":_field}})
###################################################
            _fid = self.get_concepts(**_get_concepts_dict)
###################################################
            print ("\n[{0}] {1}: ".format(_fid,self.current_field_name.get(_fid)))

            _get_concepts_dict.update({"fields-dict":{"field-json-key":"values","field-name":_field}})
            _field_vals = self.get_concepts(**_get_concepts_dict)

            if _field_vals == Action.no_value_found:
                print("There are no values associated with this filter!")
                self.reset_instance_containers_for_new_query()
                return Action.success
            else:#7-12-17
                self.print_element_values(_field_vals)

            _more = True
            _loop_count = 0
            while _more:
            # _values = _values.split()
                if _range_logic:
                    if _loop_count == 0:
                        _values = input("\n\nEnter the first value: ")
                        while not self.user_input_okay(**{"check":{"single-entry":str(_values)}}):
                            _values = ""; _values = input("\n\nEnter a valid first value: ")
                        _query += "{0} {1} {2}".format(self.current_concept_name,_operator,_values)
                        _input_values.append(str(_values))
                        _loop_count = _loop_count + 1
                    elif _loop_count == 1:
                        _values = input("\n\nEnter the second value: ")
                        while not self.user_input_okay(**{"check":{"single-entry":str(_values)}}):
                            _values = ""; _values = input("\n\nEnter a valid second value: ")
                        if _input_values.count(str(_values)) != 0:
                            while _input_values.count(str(_values)) != 0 :
                                _values = input("\nEnter a unique second value(s): ")
                        
                        #7-12-17
                        while not self.user_input_okay(**{"check":{"range-values":{"lower-bound":_input_values[0],"upper-bound":str(_values)}}}):
                            _values = ""; _values = input("\n\nUpper bound cannot be less than lower bound: ")
                        #
                        _input_values.append(str(_values))
                        _query += " {0} {1}".format(_operator_logic_language,_values)
                        _loop_count = _loop_count + 1
                elif _equality_logic:
                    _values = input("\n\nEnter the value: ")
                    while not self.user_input_okay(**{"check":{"single-entry":str(_values)}}):
                        _values = ""; _values = input("\n\nEnter a valid value: ")
                    _query += "{0} {1} {2}".format(self.current_concept_name,_operator,_values)
                    _input_values.append(str(_values))
                    _loop_count = _loop_count + 1
                    _more = False; break
                else:
                    _values = input("\n\nEnter the value (or enter 'as csv' to enter a comma seperated list of values): ")
                    ########################
                    #7-17-17
                    #B2BASSINET-271
                    if "as csv" in _values:
                        _values=""; _values = input("\n\nEnter the list of values (seperated by commas): ")

                        x = _values.split(", ")                          

                        if _loop_count == 0:
                            if _operator in Phrases.negative_regex_query_operators: 
                                _query += "{0} {1} {2}".format(self.current_concept_name,Phrases.csv_operators[0],_values)
                            else:
                                _query += "{0} {1} {2}".format(self.current_concept_name,Phrases.csv_operators[1],_values)
                            _loop_count = _loop_count + 1                        
                        else:
                            if len(_input_values) != 0:
                                _unique_values = [v for v in x if str(v) not in _input_values ]
                                try:
                                    if len(_unique_values) != 0:
                                        _append_query_with_previous_inputs = ", ".join(_unique_values[0:len(_unique_values)-1])

                                    if _operator in Phrases.negative_regex_query_operators:
                                        _query = "{0} {1} {2} {3}".format(self.current_concept_name,Phrases.csv_operators[0],_values,_append_query_with_previous_inputs)
                                    else:
                                        _query = "{0} {1} {2} {3}".format(self.current_concept_name,Phrases.csv_operators[1],_values,_append_query_with_previous_inputs)
                                    # sys.exit("unique vals: {0}\nlength: {1}\n".format(_unique_values,len(_unique_values)))
                                #     if len(_unique_values) > 2:
                                #         _append_query_with_previous_inputs = ", ".join(_unique_values[0:len(_unique_values)-2])
                                #         _append_query_with_previous_inputs += " or {0}".format(_unique_values[len(_unique_values)-1])
                                except Exception as _bad_index:
                                    # _append_query_with_previous_inputs = " or {0}".format(_unique_values[len(_unique_values)-1])
                                    pass
                       
                        [ _input_values.append(str(e)) for e in x if e not in _input_values ]

                    elif _loop_count == 0:
                    ########################

                    # if _loop_count == 0:
                        _query += "{0} {1} {2}".format(self.current_concept_name,_operator,_values)
                        _input_values.append(str(_values))
                        _loop_count = _loop_count + 1                                             

                    else:
                        if _input_values.count(str(_values)) == 0:
                            _input_values.append(str(_values))
                            _query += " {0} {1}".format(_operator_logic_language,_values)

                if _range_logic:
                    if _loop_count == 2:#we are dealing with a logical 'and' statement, only need two values
                        _more = False; _values = "";
                    else:
                        _values = ""; continue
                else:
                   
                    _another_value = input("\nEnter another value [y/n]: ")

                    if _another_value in Phrases.cancel_current_action:
                        _more = False
                        _values = "";
                        self.reset_instance_containers_for_new_query()
                        return Action.cancel_action
                    elif _another_value in Phrases.quit_api:
                        _more = False
                        sys.exit("\nGoodbye!\n")
                    elif _another_value not in Phrases.positive_responses:
                        _more = False
                    else:
                        _values = "";

            if _fid not in _fid_list:
                _fid_list.append(_fid)
            ############################################################################################################################################
            [ _val_list.append({"label": x['label'], "value" : x['value']}) for x in _field_vals if x['label'] in _input_values and x['value'] is not None and {"label":x['label'],"value":x['value']} not in _val_list ]
            # sys.exit("\n\n******[test vals list filter]******: {0}\n\n".format(_val_list))
            ############################################################################################################################################
        try:
            if len(_op_list) == 0:
                if _range_logic or _equality_logic:
                    _get_concepts_dict.update({"fields-dict":{"logic":True,"field-json-key":"operators","field-name":_field}})
                else:
                    _get_concepts_dict.update({"fields-dict":{"field-json-key":"operators","field-name":_field}})

                _op_list = self.get_concepts(**_get_concepts_dict)

        except Exception as _bad_index:
            print("*[build_query] Exception (_bad_index): {0}\n{1}*\n".format(_bad_index))
        # print("{0}".format(_val_list))

        ###############
        #B2BASSINET-248
        ###############

        if len(_val_list) == 0:
            print("There are no values to enter into the context under the concept: {0}".format(self.current_concept_name))
            self.reset_instance_containers_for_new_query()
            return Action.success

        print("{0}".format(_op_list))
        print("{0}".format(_fid_list))
        if _language_list is not None:
            for k in _language_list:
                print("[{0}]Query: {1}\n\n".format(k,_language_list[k]))
        else:
            print("Raw Query: {0}".format(_query))
        _api_home_links = self.get_api_keys()['_links']
        _filtered_vals = []
        try:
            _filtered_ops = _op_list
            if _equality_logic or _range_logic:
                _comparison_op = [ _ops for _ops in _op_list if _operator in _ops[1] ]
                print("op list equality/range logic: {0}".format(_comparison_op))

        except Exception as _bad_op_index:
            sys.exit("op_list: {0}".format(_op_list))
        # print("filtered ops: {0}".format(_filtered_ops))

        _new_context_additions = []
        for i,_fid in enumerate(_fid_list):

            _get_concepts_dict.update({"fields-dict":{"field-json-key":"searchable","field-id":_fid}})
            _searchable = self.get_concepts(**_get_concepts_dict)
            if "key" in self.current_concept_simple_type.get(_fid) or _searchable:
                _filtered_vals = [v for v in _val_list if v['value'] is not None]
            else:
                _filtered_vals = [v['value'] for v in _val_list if v['value'] is not None]

            if len(_fid_list) > 1:
                print("query language: {0}".format(_language_list[_fid]))
                x = _language_list[_fid].split(';')
                try:
                    _loc_sub_val = [x[1]]
                    _sub_filtered_vals_list = [ v for v in _val_list if v['label'] in x ]
                    _cleaned_vals_list = []
                    _loc_sub_query = "{0} ".format(x[0])
                    for n,s in enumerate(x):
                        if n % 2 == 1 and n < len(x) - 1:
                            _loc_sub_query += ", ".format(x[n])
                            if "key" in self.current_concept_simple_type.get(_fid):
                                [ _cleaned_vals_list.append(v) for v in _val_list if v['label'] == x[n] ]
                            else:
                                [ _cleaned_vals_list.append(v['value']) for v in _val_list if v['label'] == x[n] ]
                        elif n % 2 == 1 and n == len(x) - 1:
                            _loc_sub_query += "or {0}".format(x[n])
                            if "key" in self.current_concept_simple_type.get(_fid):
                                [ _cleaned_vals_list.append(v) for v in _val_list if v['label'] == x[n] ]
                            else:
                                [ _cleaned_vals_list.append(v['value']) for v in _val_list if v['label'] == x[n] ]
                    # print("(while) filtered ops: {0}\nPhrases: {1}".format(_filtered_ops[0], Phrases.negative_regex_query_operators))
                    if _filtered_ops[0] not in Phrases.negative_regex_query_operators:
                        if not _searchable:
                            _new_context_additions.append( {"cleaned_value" : _sub_filtered_vals_list, "concept" : self.current_concept_id, "field" : _fid, "language" : _loc_sub_query, "operator" : "in", "value" : _cleaned_vals_list } )
                        else:
                            _new_context_additions.append( {"value" : _sub_filtered_vals_list, "concept" : self.current_concept_id, "field" : _fid, "language" : _loc_sub_query, "operator" : "in" } )
                    else:
                        if not _searchable:
                            _new_context_additions.append( {"cleaned_value" : _sub_filtered_vals_list, "concept" : self.current_concept_id, "field" : _fid, "language" : _loc_sub_query, "operator" : "in", "value" : _cleaned_vals_list } )
                        else:
                            _new_context_additions.append( {"value" : _sub_filtered_vals_list, "concept" : self.current_concept_id, "field" : _fid, "language" : _loc_sub_query, "operator" : "in" } )
                        # _new_context_additions.append( {"cleaned_value" : _sub_filtered_vals_list, "concept" : self.current_concept_id, "field" : _fid, "language" : _loc_sub_query, "operator" : "-in", "value" : _cleaned_vals_list } )

                except Exception as _invalid_array_index:
                    try:
                        print("*[build_query] Exception (_invalid_array_index): {0}\n{1}*\n".format(_invalid_array_index,sys.exc_info()[2].print_exc()))      
                    except Exception as _no_print_exc:
                        print("*[build_query] Exception (_invalid_array_index): {0}\n{1}*\n".format(_invalid_array_index,_no_print_exc))
                        sys.exit("Safe exit.\n")
            elif _equality_logic:
                _query = "{0} {1} {2}".format(self.current_concept_name,_comparison_op[0][1],_values)
                # print("Reset Query (_equality_logic new context addition): {0}".format(_query))
                _new_context_additions.append( {"concept" : self.current_concept_id, "field" : _fid, "language" : _query, "operator" : _comparison_op[0][0], "value" : _filtered_vals[0] } )
            elif _range_logic:
                    # print("range_logic new context addition): {0}, range, filtered vals: {1}".format(_query, _filtered_vals))
                _new_context_additions.append( {"concept" : self.current_concept_id, "field" : _fid, "language" : _query, "operator" : _comparison_op[0][0], "value" : _filtered_vals } )
                    # print("range_logic new context addition): {0}, -range, filtered vals: {1}".format(_query, _filtered_vals))
            elif _filtered_ops[0] not in Phrases.negative_regex_query_operators:
                # print("(elif) filtered ops: {0}\nPhrases: {1}".format(_filtered_ops, Phrases.negative_regex_query_operators))
                # _new_context_additions.append( {"cleaned_value" : _val_list, "concept" : self.current_concept_id, "field" : _fid, "language" : _query, "operator" : "in", "value" : _filtered_vals } )#comment out 7-26-16
                if not _searchable:
                    _new_context_additions.append( {"cleaned_value" : _val_list, "concept" : self.current_concept_id, "field" : _fid, "language" : _query, "operator" : "in", "value" : _filtered_vals } )
                else:
                    _new_context_additions.append( {"value" : _val_list, "concept" : self.current_concept_id, "field" : _fid, "language" : _query, "operator" : "in" } )
            else:
                # print("(else _fid_list == 1) cleaned_value: {0}".format(_val_list))
                # _new_context_additions.append( {"cleaned_value" : _val_list, "concept" : self.current_concept_id, "field" : _fid, "language" : _query, "operator" : "-in", "value" : _filtered_vals } )#comment out 7-26-16
                if not _searchable:
                    _new_context_additions.append( {"cleaned_value" : _val_list, "concept" : self.current_concept_id, "field" : _fid, "language" : _query, "operator" : "-in", "value" : _filtered_vals } )
                else:
                    _new_context_additions.append( {"value" : _val_list, "concept" : self.current_concept_id, "field" : _fid, "language" : _query, "operator" : "-in" } )
        try:
            if self.context_exists():
                _get_request_items = {"ret":"json"}
                _context_children = self.get_context(**_get_request_items)['json']['children']
                c = []
                [ c.append(_context_children.index(x)) for x in _context_children if x["concept"] == self.current_concept_id and _context_children.index(x) not in c ]
                
                if len(c) == 1:
                    i = _context_children[c[0]]
                    jfids = [ x['field'] for x in _context_children if x["field"] in _fid_list ]
                    rfids = [ rf for rf in _fid_list if rf not in jfids ]
                    jfs = [ _context_children.index(x) for x in _context_children if x["field"] in _fid_list ]
                    # print("jfs: {0}".format(jfs))
                    if len(jfs) != 0:
                        for f in jfs:
                            _new_context = [ _nca for _nca in _new_context_additions if _nca['field'] == _context_children[f]['field'] ]
                            try:
                                _context_children[f] = _new_context[0]
                            except Exception as _bad_tuple_index:
                                print("\n*[build_query] Exception (len(c) == 1) try: {0}\n{1}*\n".format(_bad_tuple_index,_bad_tuple_index.args))
                            # print("\nadded: {0}\n".format(_new_context[0]))

                    if len(rfids) != 0:#get a list of the remaining field ids that weren't found in the current context the user wants to add
                        print("rfids: {0}\n".format(rfids))
                        # append each of the the remaining fields to the current context
                        [ _context_children.append(x) for x in _new_context_additions if x["field"] in rfids ]
                    # print("\n\n\n**context update**: {0}".format(_context_children))
                elif len(c) > 1:
                    jfids = [ x['field'] for x in _context_children if x["field"] in _fid_list ]#get a list of ids for matched field ids in current context
                    rfids = [ rf for rf in _fid_list if rf not in jfids ]
                    jfs = [ (_context_children.index(x),x) for i,x in enumerate(_context_children) if x["field"] in _fid_list ]#get a list of indexes for matched field ids in current context
                    # print("jfs: {0}\nlen(rfids): {1}\n".format(jfs,len(rfids)))

                    if len(jfs) != 0:
                        for jf in jfs:
                            _new_context = [ _nca for _nca in _new_context_additions if _nca['field'] == _context_children[jf[0]]['field'] ]
                            try:
                                _context_children[jf[0]] = _new_context[0]
                            except Exception as _bad_tuple_index:
                                print("\n*[build_query] Exception (len(c) == 1) try: {0}\n{1}*\n".format(_bad_tuple_index,_bad_tuple_index.args))

                        # print("\n\n\n***context update (jfs)***: {0}".format(_context_children))
                    if len(rfids) != 0:#get a list of the remaining field ids that weren't found in the current context the user wants to add
                        print("rfids: {0}\n".format(rfids))
                        # append each of the the remaining fields to the current context
                        [ _context_children.append(x) for x in _new_context_additions if x["field"] in rfids ]

                    # print("\n\n\n***context updated (len(c > 1))***: {0}".format(_context_children))
                elif len(c) == 0:#there is no matching concept currently in the context, so we must add the current user query to an existing context
                    #added appending of new contexts to current context if it exists but there is no matching concept id to update--need to test
                    [ _context_children.append(_nca) for _nca in _new_context_additions ]
                    # print("\n\n\ncontext update: {0}".format(_context_children))
                #now we put the updated context into the context that already exists                    
                try:
                    if UserWantsTo.do(Action.update_the_filter_with_your_query):
                        _update_request_items = {"update":_context_children}
                        _update_context_request = self.get_context(**_update_request_items)
                        if _update_context_request:
                            print("\n***Filter updated successfully***\n")
                            self.peek_filters()
                        else:
                            print("\n***Filter update failed!***\n")
                except Exception as _bad_put:
                    print("*[build_query] Exception (_bad_put_request): {0}*\n".format(_bad_put))
                    sys.exit("Safe exit.\n")
            else:
                try:
                    if UserWantsTo.do(Action.update_the_filter_with_your_query):
                        _post_request_items = {"update":_new_context_additions}
                        _create_context_request = self.get_context(**_post_request_items)
                        if _create_context_request:
                            print("\n***Filter updated successfully***\n")
                            self.peek_filters()
                        else:
                            print("\n***Filter updated failed!***\n")
                except Exception as _bad_post:
                    print("*[build_query] Exception (_bad_post): {0}*\n".format(_bad_put))
                    sys.exit("Safe exit.\n")

        except Exception as argument:
            try:
                print("*[build_query] Exception: {0}\nargs: {1}\n{2}\n_________________\n".format(argument,argument.args))
            except Exception as _no_exec_info:
                print("*[build_query] Exception: {0}\n".format(_no_exec_info))

    def get_fid(self,searchItem):
        """
        deprecated:

            use get_concepts with 'field' kwarg and 'field-json-key' set to 'id'

        description: 

            Method for getting the field id from a field json object

        returns:

            field id IF the 'concept name' and 'field name' match
        """
        return self.get_concepts(**{"ret":"field", "name":searchItem, "field-json-key":"id"})


    def get_op_index(self,_fid,_operator):
        """
        deprecated:

            use get_concepts with 'field' kwarg and 'field-json-key' set to 'operators'

        description: 

            Method for getting the operators of a field.

        returns: 

            list of indexs for operators that are associated with the field and given operator from user to build a query with

        """
        _ret = []        
        [ _ret.append(self.current_field_operators.get(_fid).index(o)) for o in self.current_field_operators.get(_fid) if o.count(_operator) == 1 ]
        return _ret

    def toggle_query(self,oauth):
        """
        description: 

            Method for getting and storing the pcgc csrftoken and pcgc session id needed to make "put" and "post" requests to the 
            context

        sets:
            
            self._pcgc_csrftoken
            self._pcgc_sessionid
            self.session_cookie_jar
            self.session_post_header

        """
        #add csrftoken to instance 
        query_url = "{0}/{1}".format(self.datahub_url,"query")
        query_header = {'Authorization': 'Bearer ' + self.token['access_token'], 'Referer' : self.datahub_url}
        query_request = oauth.request('get',query_url,headers=self.headers)
        pcgc_csrftoken = query_request.headers['Set-Cookie'].split(';')[0]

        # print("{0}\n{1}".format(pcgc_csrftoken,query_request.headers))
        _contexts_header = {'Authorization': 'Bearer ' + self.token['access_token'], 'X-CSRFToken' : pcgc_csrftoken }
        _contexts_cookie =  { 'pcgc_csrftoken' : pcgc_csrftoken}
        _contexts_cookie_jar = requests.utils.cookiejar_from_dict(_contexts_cookie)
        #this is necessary to get a sessionid value, this requests returns an exception, and in the exception the sessionid is one of the values in the 
        #html. '/api/contexts/1' is a non-existing context that we know gives us the exception because it does not end with a '/'
        _contexts_request = oauth.request('post',self.datahub_url+'/api/contexts/1',headers=_contexts_header, cookies=_contexts_cookie_jar,stream=True)
        # print("{0}\n".format(requests.utils.dict_from_cookiejar(query_request.cookies)))
        lines = _contexts_request.iter_lines()
        first_line = next(lines)
        if _contexts_request.encoding is None:
            _contexts_request.encoding = 'utf-8'

        for line in _contexts_request.iter_lines():
            if str(line).find("pcgc_sessionid=") != -1 and str(line).find('\\n') == -1:
                x = str(line)
                break
        x = x.split()

        for e in x:
            if e.find('sessionid') != -1:
                reg_ex = re.search( r'(pcgc_sessionid=.*([A-Z]+|[0-9]+|[a-z]+))', e )
                if reg_ex:
                    # print("reg: {0}\nreg: {1}".format(reg_ex.group(0),reg_ex.groups()))
                    e = reg_ex.group(0)
                    if(e.find('&#39;</pre></td>\'')):
                        e = e.strip('#39;</pre></td>\'')
                        sessionid = "p" + e.split('&')[0]
                    else:
                        sessionid = "p" + e
                    break
        # print ("csrftoken: {0}\nsession id: {1}".format(pcgc_csrftoken,self.sessionid))
        self._pcgc_csrftoken = pcgc_csrftoken.split('=')[1]
        self._pcgc_sessionid = sessionid.split('=')[1]
        _contexts_cookie = {'pcgc_csrftoken' : self._pcgc_csrftoken,'pcgc_sessionid' : self._pcgc_sessionid}
        self.session_cookie_jar = requests.utils.cookiejar_from_dict(_contexts_cookie)
        self.session_post_header = {'Authorization': 'Bearer ' + self.token['access_token'], 'X-CSRFToken' : self._pcgc_csrftoken, 'X-Requested-With' : 'XMLHttpRequest','Referer' : self.datahub_url+'/query/'}

    def clear_filters(self):
        """
        ###############
        #B2BASSINET-225
        ###############

        description: 

            Method that makes a get request to the clear_query url, resetting the context filters

        """
        if UserWantsTo.do(Action.clear_the_filters):
            try:
                _clear_url = "{0}/{1}/".format(self.datahub_url,"clear_query")
                # _clear_query_request = requests.get(_context_url,headers=self.session_post_header,cookies=self.session_cookie_jar)
                _clear_request_items = {"type":"get","url":_clear_url}
                _clear_query_request = self.requestResource(**_clear_request_items)
                if _clear_query_request.status_code == requests.codes.ok:
                    print("\n***[Filters Clear Status: {0}]***".format(_clear_query_request.reason))
                else:
                    print("\n***[Filter Clear Status: Error]***\n{0} reason: {1}".format(_clear_query_request.status_code,_clear_query_request.reason))
            except Exception as _bad_clear_filters_get:
                print("*[clear_filters] Exception (_bad_clear_filters_get): {0}\n{1}*\n".format(_bad_clear_filters_get,_bad_clear_filters_get.args))
                sys.exit("Safe exit.\n")
        else:
            print("Note: Filters not cleared!")

    def user_input_okay(self, **kwargs):       
        """
        ###############
        #B2BASSINET-226
        ###############

        description: 

            Method for sanity checking user y/n responses

        returns:

            true if the user input does not include whitespace, false otherwise
        """
        if not kwargs or "check" not in kwargs.keys():
            sys.exit("Sanity check requires a dictionary!")
        else:
            if "single-entry" in kwargs['check']:
                x = kwargs['check']['single-entry'].split()
                # x = user_input.split()
                return len(x) == 1
            elif "range-values" in kwargs['check']:
                return float(kwargs['check']['range-values']['lower-bound']) < float(kwargs['check']['range-values']['upper-bound'])

    def reset_instance_containers_for_new_query(self):
        """
        description: 

            Method for making a request to the api server.

        sets:

            self.current_concept_id
            self.current_concept_name
            self.current_field_id
            self.current_field_values
            self.current_field_operators
            self.current_field_name

        returns:

            true after all the instance containers set during build a query are reset
        """
        try:
            self.current_concept_id = None
            self.current_concept_name = None
            self.current_field_id = []
            self.current_field_values = {}
            self.current_field_operators = {}
            self.current_field_name = {}
            return True
        except Exception as _reset_instance_containers_failed:
            try:
                print("*[reset_instance_containers_for_new_query] Exception: {0}\n{1}*\n".format(_reset_instance_containers_failed,sys.exc_info()[2].print_tb()))
            except Exception as _no_print_tb:
                print("*[reset_instance_containers_for_new_query] Exception: {0}\n{1}*\n".format(_reset_instance_containers_failed,_no_print_tb))
            return False

    def context_exists(self):
        """
        description: 

            Method for checking if there is an existing context object.

        returns:

            true if there is a context json object, false otherwise

        """
        _api_home_links = self.get_api_keys()['_links']
        _get_request_items = {"type":"get","url":_api_home_links['contexts']['href']}
        self._context = self.requestResource(**_get_request_items)
        if self._context.status_code == requests.codes.ok:
            if len(self._context.json()) != 0:
                return True
            else:
                return False
        else:
            sys.exit("[context_exists] Exiting with status: {0}\nreason: {1}".format(Action.server_request_failed, self._context.reason))

    def peek_context(self):
        """
        description: 

            Method that displays the entire context json object. Use peek_filters to display only the filters and the number of results

        """
        if self.context_exists():
            print("{0}\n\nResults: {1}".format(self._context.text,self._context.json()[0]['count']))

    def display_queries(self):
        """
        ###############
        #B2BASSINET-229
        ###############

        description: 

            Method that allows for displaying and loading of saved/public queries

        returns:

            Action.load_a_query enum value if public/saved query not found, Action.success if user does not want to load a public or saved query

        """
        _api_home_links = self.get_api_keys()['_links']
        try:
            _query_choice_type = UserWantsTo.display()
            if _query_choice_type == Action.exit_the_api:
                sys.exit("\nGoodbye!\n")
            elif _query_choice_type == Action.load_a_public_query:
                _get_request_items = {"type":"get","url":_api_home_links['public_queries']['href']}
            elif _query_choice_type == Action.load_a_saved_query:
                _get_request_items = {"type":"get","url":_api_home_links['queries']['href']}

            _queries = self.requestResource(**_get_request_items)
            if _queries.status_code == requests.codes.ok:
                if len(_queries.json()) != 0:
                    _q_dict = {}
                    [ [ print("{0}".format(_q['name'])) , _q_dict.update({_q['name'] : json.dumps(_q['context_json']) + ";" +  json.dumps(_q['view_json'])}) ] for _q in _queries.json() ]
                    print("\n")

                    if UserWantsTo.do(_query_choice_type):
                        _query_to_load = input("Enter the name of the query to load: ")
                        if _query_to_load in _q_dict.keys():
                            x = _q_dict.get(_query_to_load); x = x.split(";")
                            self.load_query_into_context(json.loads(x[0]),json.loads(x[1]),_query_choice_type)
                        else:
                            print("Could not find a query with the name: {0}".format(_query_to_load))
                            return Action.load_a_query
                    else:
                        return Action.success
            else:
                print("\n***[display_queries: Error]***\n{0}\n{1}".format(_queries.status_code,_queries.reason))
        except Exception as _queries_request_failed:
            print("*[display_queries] Exception: {0}\n*".format(_queries_request_failed))
            sys.exit("Safe exit.\n")

    def load_query_into_context(self,_query_context_json,_query_view_json,_action):
        """

        description: 

            Method for making a request to the api server.

        required parameters:
    
            query_context_json- json object to be loaded into the current context
            _query_view_json- json object of the view to be loaded
            _action- enum value of action to be carried out, defined in server_actions_helper.py

        """
        try:
            v = self.view_json
            v.update({"json" : _query_view_json})
            try: 
                _put_request_items = {"type":"put","url":self.view_url,"data":v}
                _load_query_view_json_request = self.requestResource(**_put_request_items)
                if _load_query_view_json_request.status_code == requests.codes.ok:
                    print("*View updated!*")
                    # print("\n***[Load Query (put view_json) Status: Success]***\n{0}\n{1}\n{2}".format(_load_query_view_json_request.status_code,_load_query_view_json_request.reason,_load_query_view_json_request.headers))
                else:
                    print("\n***[Load Query (put view_json) Status: Error]***\n{0}\n{1}".format(_load_query_view_json_request.status_code,_load_query_view_json_request.reason))
            except Exception as _load_query_view_json_request_failed:
                print("\n***[Load Query (put view_json) Status: Exception]***\n{0}".format(_load_query_view_json_request_failed))
                sys.exit("Safe exit.\n")
            try:
                _load_query_context_json_items = {"load":_query_context_json}
                _load_query_context_json_request = self.get_context(**_load_query_context_json_items)
                if not _load_query_context_json_request:
                    print("\n***Load Query (put context_json) Status: Error]***\n")
                    # print("\n***[Load Query (put context_json) Status: Error]***\n{0}\n{1}\n{2}".format(_load_query_context_json_request.status_code,_load_query_context_json_request.reason,_load_query_context_json_request.request.headers))
                else:
                    print("*Query loaded!*")
            except Exception as _load_query_context_json_request_failed:
                # print("\n***[Load Query (put context) Status: Exception]***\n{0}".format(_load_query_context_json_request_failed))
                sys.exit("Load Query (put context) Status: Exception] Safe exit.\n")

        except Exception as _load_query_into_context_failed:
            print("*[load_query_into_context] Exception: {0}*\n".format(_load_query_into_context_failed))
            sys.exit("Safe exit.\n")
        
    def requestResource(self,**kwargs):
        """

        description: 

            Method for making a request to the api server.

        required kwargs:

            "type" : [ "get" | "post" | "put" ]
            "url" : request url

        optional kwargs:

            "h" : header

            "p" : if "type" is "get", "p" kwarg is used to set the params option of the requests get request.

            "data" : if "type" is "post" or "put", this kwarg will set the 'json' parameter of the requests method. Value should be a dictionary
                    i.e.-   v.update({ 'json' : {'children':kwargs['update'],'type':'and'}})
                            _put_request_items.update({"data":v})
                            _put_json_request = self.requestResource(**_put_request_items)

        returns:

            requests response object of request

        """
        if kwargs:
            if "type" not in kwargs.keys() or "url" not in kwargs.keys():
                sys.exit("Bad request (either no type or url given in dictionary! Check the arguments... Safe exit!")

            if "get" in kwargs['type']:
                if "p" in kwargs.keys():
                    return requests.get(kwargs['url'],headers=self.session_post_header,cookies=self.session_cookie_jar,params=kwargs['p'])
                else:
                    if "h" in kwargs.keys():
                        return requests.get(kwargs['url'],headers=kwargs['h'])
                    else:
                        return requests.get(kwargs['url'],headers=self.session_post_header,cookies=self.session_cookie_jar)
            elif "post" in kwargs['type']:
                return requests.post(kwargs['url'],headers=self.session_post_header,json=kwargs['data'],cookies=self.session_cookie_jar)
            elif "put" in kwargs['type']:
                return requests.put(kwargs['url'],headers=self.session_post_header,json=kwargs['data'],cookies=self.session_cookie_jar)

    def add_column_to_view_for_export(self):
        """
        ####################
        #B2BASSINET-254
        ####################

        description: 

            Method for adding a filters to the data to be exported. 

        sets:

            self.view_json
            self.current_export_column_cids

        returns:

            Action.success if adding new columns to the view was successful, Action.server_request_failed if unsuccessful

        """
        _api_home_links = self.get_api_keys()['_links']
        # _get_from_concept_obj = {"ret": "json"}; _concepts_as_json_obj = self.get_concepts(**_get_from_concept_obj)
        _add_columns = True
        _while_loop_count = 0
        while _add_columns:
            try:

                if self.get_current_export_columns_in_view():
                    if _while_loop_count == 0:
                        print("\n{0}".format(appendChar("Current columns set for export:", "-")))
                        [ self.print_concept_name(_column_cid) for _column_cid in self.current_export_column_cids ]
                        _while_loop_count = 1
                    try:
                        _section = self.get_filters(**{"action":"add-columns"})
                        # sys.exit("section: {0}")
                        add_concept_id = []
                        if isinstance(_section,dict):
                            [ [ add_concept_id.append(self.get_concepts(**{"ret":"json","name":_sub_section_name})['id']) for _sub_section_name in _sub_section_list ] for _sub_section_list in _section.values() ]
                        elif isinstance(_section,list):
                            try:
                                [ add_concept_id.append(v['cid']) for v in _section ]
                                # print("inside else (isinstance): {0}\ni: {1}".format(_section, i))
                            except Exception as _tuple_index_out_of_range:
                                try:
                                    add_concept_id = []
                                    [ add_concept_id.append(self.get_concepts(**{"ret":"json","name":v})['id']) for v in _section ]
                                except Exception as _get_index_failed_twice:
                                    sys.exit("Exception 1: {0}, Exception 2: {1}, section: {2}".format(_tuple_index_out_of_range,_get_index_failed_twice,_section))
                        # print("add concept id: {0}\ni: {1}\nsection: {2}".format(add_concept_id, i, _section))
                        ####################################
                        initial_size = len(self.current_export_column_cids)
                        [ self.current_export_column_cids.add(_id) for _id in add_concept_id if _id not in self.current_export_column_cids ]
                        if len(add_concept_id) != 0:
                            self.view_json.update({'json':{'columns':list(self.current_export_column_cids),'ordering':[]}})
                            _put_request_items = {"type":"put","url":self.view_url,"data":self.view_json}
                            _add_column_json_request = self.requestResource(**_put_request_items)

                            if _add_column_json_request.status_code == requests.codes.ok:
                                # print("Added: {0}".format(search_category_by_name))
                                print("\n{0}".format(appendChar("Added","-")))
                                [ self.print_concept_name(_column_fid) for _column_fid in add_concept_id ]      
                            else:
                                print("\n***[Load Query (put context_json) Status: Error]***\n{0}\n{1}".format(_add_column_json_request.status_code,_add_column_json_request.reason))
                                return Action.server_request_failed
                        else:
                            print("Nothing to be added!")
                    except Exception as _add_column_to_view_for_export_json_request_failed:
                            print("\n***[add_column_to_view_for_export (put context) Status: Exception]***\n{0}".format(_add_column_to_view_for_export_json_request_failed))
                            sys.exit("Safe exit.\n")
                    more_columns = ""; more_columns = input("\nDo you want to add another column to export [y/n]: ");

                    if more_columns in Phrases.cancel_current_action:
                        _add_columns = False; return Action.cancel_action
                    elif more_columns in Phrases.quit_api:
                        sys.exit("\nGoodbye!\n")
                    elif more_columns in Phrases.negative_responses:
                        print("\n{0}".format(appendChar("Current columns set for export:", "-")))
                        [ self.print_concept_name(_concept_fid) for _concept_fid in self.current_export_column_cids ]
                        _add_columns = False; return Action.success
                else:
                    print("\nIssue retrieving current columns from view!\n")
                    _add_columns = False; return Action.server_request_failed
            except Exception as argument:
                print("*[add_column_to_view_for_export] Exception: {0}*\n".format(argument))
                sys.exit("Safe exit.\n")

    def get_current_export_columns_in_view(self):
        """
        ####################
        #B2BASSINET-254
        ####################

        description: 

            Method to call before updating columns for export of data. 

        sets:

            self.view_url
            self.view_json
            self.current_export_column_cids

        returns:

            true if get request to view url is successful, false otherwise

        """
        try:
            self.view_url = "{0}/{1}/".format(self.datahub_url,"api/views")
            _get_request_items = {"type":"get","url":self.view_url}
            _get_view_request = self.requestResource(**_get_request_items)
            if _get_view_request.status_code == requests.codes.ok:
                self.view_url = _get_view_request.json()[0]['_links']['self']['href']
                self.view_json = _get_view_request.json()[0]
                self.current_export_column_cids = set(self.view_json['json']['columns']);
                if len(self.variant_ids) == 0:
                    self.variant_ids = [ self.get_concepts(**{"ret":"json","name":x})['id'] for x in self.show_query_sub_Categories(**{"category":"Variants","action":"return"}) ]
                return True
            else:
                return False
        except Exception as _bad_view_request:
            print("*[get_current_export_columns_in_view] Exception: {0}*\n".format(_bad_view_request))
            sys.exit("Safe exit.\n")

    def set_concepts(self):
        """
        description: 

            Method for storing concepts json object into api instance for quick lookup

        sets:

            self.concepts

        """
        _api_home_links = self.get_api_keys()['_links']
        _get_request_items = {"type":"get","url":_api_home_links['concepts']['href']}
        self.concepts = self.requestResource(**_get_request_items)

    def get_field_dictionary_by_concept(self,**kwargs):
        """
        description: 

            Method for quick access to field json object

        required kwargs: 

            "name": name of the field to return
            "cid": concept id of the field return

        sets:

            self.current_concept_id
            self.current_concept_name

        returns:

            json object of field 

        """
        if not kwargs or ("name" not in kwargs.keys() and "cid" not in kwargs.keys()):
            sys.exit("Must provide argument dictionary to use the method 'get_field_dictionary_by_concept' with either 'name' or 'cid' kwarg!")
        else:
            if "name" in kwargs.keys():
                _concepts_obj_as_json = self.get_concepts(**{"ret": "json","name":kwargs['name']})
            elif "cid" in kwargs.keys():
                _concepts_obj_as_json = self.get_concepts(**{"ret": "json","cid":kwargs['cid']})
        if len(_concepts_obj_as_json) > 0:
            self.current_concept_id = _concepts_obj_as_json['id']
            self.current_concept_name = _concepts_obj_as_json['name']
            return _concepts_obj_as_json
        return -1

    def remove_filter_from_context(self):
        """
        ####################
        #B2BASSINET-225
        ####################

        description: 

            Method for removing filters from the current context

        returns:

            true if removal of filter(s) is successful, otherwise false
       
        """
        _remove_filters = True
        while _remove_filters:
            if self.context_exists():
                self.peek_filters()
                _filter_to_remove = input("\nEnter the field id or language of the filter to remove, or 'all': ")
                if "all" not in _filter_to_remove:
                    if str(_filter_to_remove).isnumeric():
                        _get_context_dict = {"remove":"filter", "field-id":int(_filter_to_remove)}
                    else:
                        _get_context_dict = {"remove":"filter", "language":_filter_to_remove}
                else:
                    _get_context_dict = {"remove":"all"}
                remove_filter_status = self.get_context(**_get_context_dict)
                if remove_filter_status:
                    _remove_another_filter = ""; _filter_to_remove = "";
                    if self.context_exists():
                        _remove_another_filter = input("Do you want to remove another filter [y/n]: ")
                        if "y" not in _remove_another_filter:
                            _remove_filters = False
                    else:
                        _remove_filters = False
                else:
                    _remove_filters = False
                    sys.exit("Removing the filter was unsuccessful. Restart the api and try again.")
        return True

    def get_context(self, **kwargs):
        """
        description: 

            Method for interacting with the current context if it exists. Will handle creating a "post" request to the
            context if there is no context currently.

        required kwargs: 

            "remove": [ "all" | "filter" ]
            "language": natural language of the filter to be removed, as it is displayed by peek_filters method

        or

            "update": json dictionary of key,value filters to be "put" into the context

        or 

            "load": context json object

        or 

            "ret": "json"

        returns:

            true if request made to context url is successful, false otherwise        
        
        """
        try:
            if not kwargs: return False
            else:
                if self.context_exists():
                    # sys.exit("keys: {0}\nu: {1}\nu l: {2}\nu l r: {3}".format(kwargs.keys(), "update" not in kwargs.keys(), "update" not in kwargs.keys() and "load" not in kwargs.keys(),  "update" not in kwargs.keys() and "load" not in kwargs.keys() and "remove" not in kwargs.keys()))
                    if "update" not in kwargs.keys() and "load" not in kwargs.keys():
                        if "remove" not in kwargs.keys() and "ret" not in kwargs.keys():   
                            print("[get_context] (else) No 'update', 'load', ret or 'remove' kwargs object provided in dictionary!")
                            return False

                    v = self._context.json()[0]
                    _put_request_items = {"type":"put","url":self._context.json()[0]['_links']['self']['href']}
                    _get_request_items = {"type":"get","url":self._context.json()[0]['_links']['self']['href']}
                    if "remove" in kwargs.keys():
                        if "filter" in kwargs['remove'] and len(v['json']['children']) > 1:
                            if "language" in kwargs.keys():
                                # print("v before removal of {0}: {1}, size: {2}".format(kwargs['language'],v['json']['children'],len(v['json']['children'])))
                                [v['json']['children'].remove(i) for i in v['json']['children'] if i['language'] == kwargs['language']]
                                # print("\nv after removal {0}: {1}, size: {2}".format(kwargs['language'],v['json']['children'],len(v['json']['children'])))
                                _put_request_items.update({"data":v})
                                _put_request = self.requestResource(**_put_request_items)
                                if _put_request.status_code == requests.codes.ok:
                                    self.peek_filters()
                                    return True
                                else:
                                    print("[get_context] (if) Status code: {0}\nReason: {1}".format(_put_request.status_code,_put_request.reason))
                                    return False
                            elif "field-id" in kwargs.keys():
                                [v['json']['children'].remove(i) for i in v['json']['children'] if i['field'] == kwargs['field-id']]
                                # print("\nv after removal {0}: {1}, size: {2}".format(kwargs['language'],v['json']['children'],len(v['json']['children'])))
                                _put_request_items.update({"data":v})
                                _put_request = self.requestResource(**_put_request_items)
                                if _put_request.status_code == requests.codes.ok:
                                    self.peek_filters()
                                    return True
                                else:
                                    print("[get_context] (if) Status code: {0}\nReason: {1}".format(_put_request.status_code,_put_request.reason))
                                    return False
                            else:
                                print("\n[get_context] No 'language' or 'field-id' kwarg provided!\n")
                                return False
                        elif "all" in kwargs['remove'] or len(v['json']['children']) == 1:
                            self.clear_filters()
                            return True
                        else:
                            return False
                    elif "update" in kwargs.keys() and kwargs['update'] is not None:
                        v.update({ 'json' : {'children':kwargs['update'],'type':'and'}})
                        _put_request_items.update({"data":v})
                        _put_json_request = self.requestResource(**_put_request_items)
                        if _put_json_request.status_code == requests.codes.ok:
                            return True
                        else:
                            print("[get_context] (elif update) Status code: {0}\nReason: {1}\nv: {2}".format(_put_json_request.status_code,_put_json_request.reason,v))
                            return False
                    elif "load" in kwargs.keys() and kwargs['load'] is not None:
                        v.update({ 'json' : kwargs['load']})
                        _put_request_items.update({"data":v})
                        _put_json_request = self.requestResource(**_put_request_items)
                        if _put_json_request.status_code == requests.codes.ok:
                            return True
                        else:
                            print("[get_context] (elif load) Status code: {0}\nReason: {1}".format(_put_json_request.status_code,_put_json_request.reason))
                            return False
                    elif "ret" in kwargs.keys():
                        if "json" in kwargs['ret']:
                            return self._context.json()[0]
                else:                   
                    _context_url = "{0}/{1}/".format(self.datahub_url,"api/contexts")                        
                    _post_request_items = {"type":"post","url":_context_url}
                    if "update" not in kwargs.keys() and "load" not in kwargs.keys():
                        print("[get_context] (else) No 'update' or 'load' kwargs object provided in dictionary!")
                        return False

                    if "update" in kwargs.keys() and kwargs['update'] is not None:
                        _post_request_items.update({"data":{'json':{'children':kwargs['update'],'type':'and'},'session':True}})
                    elif "load" in kwargs.keys() and kwargs['load'] is not None:
                        _post_request_items.update({"data":{'json':kwargs['load'],'session':True}})
                    _post_context_request = self.requestResource(**_post_request_items)
                    if _post_context_request.status_code == requests.codes.created:
                        return True
                    else:
                        print("[get_context] (else) Status code: {0}\nReason: {1}".format(_post_context_request.status_code,_post_context_request.reason))
                        return False
        except Exception as _get_context_failed:
            sys.exit("[get_context] Exception: {0}\n".format(_get_context_failed))

    def peek_filters(self):
        """
        description: 

            Method for organized display of the current filters set in the context.
            of a concept.
       
        """
        if self.context_exists():
            print("{0}".format(appendChar("\nCurrent Filters ( {0} result(s))".format(self._context.json()[0]['count']),"-")))
            [ print("[{0}] {1}".format(e['field'],e['language'])) for e in self._context.json()[0]['json']['children'] ]

    def get_filters(self, **kwargs):
        """
        description: 

            Method for building a query or adding columns. When building a query, this method
            will allow for more organized navigation of groups of filters and the sub-Categories
            of a concept.

            When adding columns, this will allow for quicker, more organized navigation of the columns
            to add to the export data.

        required kwargs: 

            "action": [ "query" | "add-columns" ]

        returns:

            single filter or a list of filters of a specified api concept group

        """
        if not kwargs or "action" not in kwargs.keys():
            sys.exit("You need to supply a kwargs dictionary with 'action' kwarg set to either query or add columns to use get_filters method!")
        else:

            self.show_group_labels(); search_key = input("\nWhat part of the api do you want to query: ");
            
            if search_key in Phrases.cancel_current_action:
                return -1
            elif search_key in Phrases.quit_api:
                sys.exit("\nGoodbye!\n")

            _show_query_params = {"category":search_key,"action":"show","sections":True}
            self.show_query_sub_Categories(**_show_query_params)

            _show_query_params.update({"action":"return"}); search_category_by_name= "";
            
            if "query" in kwargs['action']:

                if search_key in Categories.groups_with_sections:
                    search_category_by_name = input("\nWhich group would you like to expand: ");
                    _show_query_params.update({"action":"show","sub-category":search_category_by_name,"sections":False})
                    self.show_query_sub_Categories(**_show_query_params)
                    _filter_column_to_retrieve = input("\nWhich field would you like to build a query with: ");
                    del _show_query_params['sections']
                    _show_query_params.update({"action":"return","filter":_filter_column_to_retrieve})
                    return self.show_query_sub_Categories(**_show_query_params)
                else:
                    search_category_by_name = input("\nWhich field would you like to add : ");
                    if "all" not in search_category_by_name :
                        _show_query_params.update({"sub-category":search_category_by_name})
                    del _show_query_params['sections']
                    return self.show_query_sub_Categories(**_show_query_params)

            elif "add-columns" in kwargs['action']:

                if search_key in Categories.groups_with_sections:
                    search_category_by_name = input("\nWhich group would you like to expand (or enter all to add entire group): ");
                    if "all" not in search_category_by_name :
                        _show_query_params.update({"action":"show","sub-category":search_category_by_name,"sections":False})
                        self.show_query_sub_Categories(**_show_query_params)
                        _filter_column_to_add = ""; 
                        _filter_column_to_add = input("\nWhich column would you like to add (enter all to add entire section): ");
                        del _show_query_params['sections']
                        _show_query_params.update({"action":"return"})
                        if "all" not in _filter_column_to_add:
                            _show_query_params.update({"filter":_filter_column_to_add})
                else:
                    search_category_by_name = input("\nWhich column would you like to add (enter all to add entire group): ");
                    if "all" not in search_category_by_name :
                        _show_query_params.update({"sub-category":search_category_by_name})
                    del _show_query_params['sections']

                # sys.exit("returning: {0}\nparams: {1}".format(self.show_query_sub_Categories(**_show_query_params),_show_query_params))
                return self.show_query_sub_Categories(**_show_query_params)

    def remove_column_from_view_for_export(self):
        """
        ####################
        #B2BASSINET-257
        ####################

        description: 

            Method for removing filters from the data to be exported. 

        sets:

            self.view_json
            self.current_export_column_cids

        returns:

            Action.success if removing columns from the view was successful, Action.server_request_failed if unsuccessful

        """
        _remove_columns = True
        while _remove_columns:
            try:
                initial_size = len(self.current_export_column_cids)
                if self.get_current_export_columns_in_view():
                    print("\n{0}".format(appendChar("Current columns set for export:", "-")))
                    [ [ print("[{0}]: ".format(_column_cid), end=" "), self.print_concept_name(_column_cid) ] for _column_cid in self.current_export_column_cids ]

                    _remove_column_by_id = input("\nWhich column would you like to remove (enter id): ")
                    
                    if _remove_column_by_id in Phrases.cancel_current_action:
                        _remove_columns = False; return Action.cancel_action
                    elif _remove_column_by_id in Phrases.quit_api:
                        sys.exit("\nGoodbye!\n")                

                    try:                        
                        if _remove_column_by_id is not None and int(_remove_column_by_id) in self.current_export_column_cids:
                            self.current_export_column_cids.remove(int(_remove_column_by_id))

                            self.view_json.update({'json':{'columns':list(self.current_export_column_cids),'ordering':[]}})
                            _put_request_items = {"type":"put","url":self.view_url,"data":self.view_json}
                            _remove_column_json_request = self.requestResource(**_put_request_items)

                            if _remove_column_json_request.status_code == requests.codes.ok:
                                print("\nRemoved: {0}\n".format(_remove_column_by_id))                                    
                            else:
                                print("\n***[remove_column_from_view_for_export (put context_json) Status: Error]***\n{0}\n{1}".format(_remove_column_json_request.status_code,_remove_column_json_request.reason))
                                return Action.server_request_failed
                        else:
                            print("Nothing to be removed by that id!")
                    except Exception as _remove_column_to_view_for_export_json_request_failed:
                            print("\n***[remove_column_to_view_for_export (put context) Status: Exception]***\n{0}".format(_remove_column_to_view_for_export_json_request_failed))
                            sys.exit("Safe exit.\n")
                    more_columns = ""; more_columns = input("\nDo you want to remove another column [y/n]: ");

                    if more_columns in Phrases.cancel_current_action:
                        _remove_columns = False; return Action.cancel_action
                    elif more_columns in Phrases.quit_api:
                        sys.exit("\nGoodbye!\n")
                    elif more_columns in Phrases.negative_responses:
                        print("\n{0}".format(appendChar("Current columns set for export:", "-")))
                        [ self.print_concept_name(_concept_fid) for _concept_fid in self.current_export_column_cids ]
                        _remove_columns = False; return Action.success
                else:
                    print("\nIssue retrieving current columns from view!\n")
                    _remove_columns = False; return Action.server_request_failed
            except Exception as argument:
                print("*[remove_column_to_view_for_export] Exception: {0}*\n".format(argument))
                sys.exit("Safe exit.\n")

    def save_query(self):
        """
        ####################
        #B2BASSINET-228
        ####################

        description: 

            Method for saving the current filters as a query. 

        returns:

            Action.success if query is saved successfully, Action.save_your_query enum value otherwise.

        """
        self.peek_filters(); _api_home_links = self.get_api_keys()['_links']
        _saved_queries_request_items = {"type":"get","url":_api_home_links['queries']['href']}

        _saved_queries_request = self.requestResource(**_saved_queries_request_items)        
        if _saved_queries_request.status_code == requests.codes.ok:
            _user_input_is_unique = False

            UserWantsTo.display(**{"item":"saved"})
            [ print(x['name']) for x in _saved_queries_request.json() ]

            #name new query
            while not _user_input_is_unique:
                _save_query_as = input("\nEnter a unique name for your new query: ")
                _unique_query_name_check = [ x for x in _saved_queries_request.json() if x['name'] == _save_query_as ]

                if len(_unique_query_name_check) == 0: _user_input_is_unique = True;
                else: print("User input is not unique: {0}".format(_save_query_as)); _save_query_as = ""

            #describe query (optional)
            _description_for_new_query = ""; 
            if UserWantsTo.do(Action.enter_a_description_for_your_query): 
                _description_for_new_query = input("\nEnter a description for your query: ");
            
            _new_query = {"name":_save_query_as,"description":_description_for_new_query}
            _new_query.update({"context_json":self._context.json()[0]['json'], "view_json":{"columns":list(self.current_export_column_cids),"ordering":[]}})

            #add users of query (optional)
            _additional_users_input = ""; _email_message_input = "";
            if UserWantsTo.do(Action.add_users_to_your_query): 
                _additional_users_input = input("\nEnter additional users (emails or usernames) for your query (multiple entries should be seperated by commas): ");
                #add email message to be included in notification email sent to shared users of query (optional)
                if UserWantsTo.do(Action.add_a_message_for_users_who_have_access_to_your_query): 
                    _email_message_input = input("\nEnter a message to be included in the notification email sent to the above users to alert\nthem that this query has been shared with them...: ");

            _new_query.update({"usernames_or_emails":_additional_users_input,"message":_email_message_input,"is_owner":True})

            #make a public query (optional)
            _make_public = False
            if UserWantsTo.do(Action.make_your_query_public):
                _make_public = True

            _new_query.update({"public":_make_public})

            _saved_queries_request_items.update({"type":"post","data":_new_query})
            # print("new quest for post: {0}".format(_new_query))#stopped here before testing add email message for notification 7-14-17
            _save_new_query_request = self.requestResource(**_saved_queries_request_items)

            if _save_new_query_request.status_code == requests.codes.created:
                print("\nQuery saved!\n")
                return Action.success
            else:
                print("\n***[Save Query (post) Status: Error]***\n{0}\n{1}".format(_save_new_query_request.status_code,_save_new_query_request.reason))
                return Action.save_your_query
        else:
            print("\nCould not get saved queries. Check the request in save_query!\n")
            return Action.server_request_failed
