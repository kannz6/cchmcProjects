import base64
import getpass
import sys

class cchmc_login:	
	def __init__(self):
		self.user_name = None 
		self.user_password = None
		self.set_user_name(); self.set_password_secure(); 

	def set_user_name(self): self.user_name = input('Username: ');

	def get_user_name(self): return self.user_name;

	def set_password_secure(self):
		try:
			self.user_password = getpass.getpass();	self.user_password = self.user_password.encode(); 
			self.user_password = base64.b64encode(self.user_password);
		except Exception as _password_error:
			try:
				print("*Password Encode/Decode Error: {0}\n{1}*\n".format(_password_error,sys.exc_info()[2].print_tb()))
			except Exception as _no_print_tb:
				print("*Password Encode/Decode Error: {0}\n{1}*\n".format(error,_no_print_tb))

	def get_password(self): return base64.b64decode(self.user_password);
