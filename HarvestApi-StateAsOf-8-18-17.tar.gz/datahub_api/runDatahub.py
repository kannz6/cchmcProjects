#!/usr/bin/env python

from datahub_api.datahub import datahub_client
from coreapi import Client,transports,codecs
import base64
from hal_codec import HALCodec
import requests
from collections import OrderedDict
import getpass
import sys
from datahub_api.api_tools.server_actions_helper import Action, UserWantsTo
from datahub_api.api_tools.common_responses import Categories
import pydoc
import socket
import io
from io import IOBase

if UserWantsTo.do(Action.display_data_client_documentation):
	pydoc.doc(datahub_client);sys.exit()

datahub = datahub_client('curlapi', 'cBiT4ur7', 'http://bmipcgcd1.chmcres.cchmc.org')
chmcloginusername = input('Username: ')
try:
	chmcloginpassword = getpass.getpass();	chmcloginpassword = chmcloginpassword.encode()
	chmcloginpassword = base64.b64encode(chmcloginpassword)
	datahub.connect(chmcloginusername, base64.b64decode(chmcloginpassword))
except Exception as error:
	print("*Password Encode/Decode Error: {0}\n{1}*\n".format(error,sys.exc_info()))
	sys.exit("Password exit ok!")

_runApiApp = True
while _runApiApp:
	if UserWantsTo.do(Action.query_data):
		another_query = True
		while another_query:

			_section = datahub.get_filters(**{"action":"query"})

			if isinstance(_section[0], dict):
				datahub.get_query_values(**{"cid":_section[0]['cid']})
				# print("cid: {0}".format(_section[0]['cid']))
				datahub.build_query(**{"lookup-concept-by":{"cid":_section[0]['cid']}})
			elif isinstance(_section, list):
				datahub.get_query_values(**{"name":_section[0]})
				# print("name: {0}".format(_section[0]))
				datahub.build_query(**{"lookup-concept-by":{"name":_section[0]}})
			# datahub.build_query()
			if UserWantsTo.do(Action.create_another_filter):
				search_key = "";search_category_by_name="";
				if datahub.reset_instance_containers_for_new_query():
					another_query = True
				else:
					another_query = False
			else:
				another_query = False
	
	if datahub.context_exists():

		if UserWantsTo.do(Action.save_your_query):
			save_result = datahub.save_query()	
			if save_result != Action.success:
				sys.exit("Issue during save query! Exiting with status code: {0} [save_result]".format(save_result))

		datahub.peek_filters()
		if UserWantsTo.do(Action.remove_a_filter):
			if not datahub.remove_filter_from_context():
				sys.exit("\nUpdate filters failed! Exiting program\n")

		if UserWantsTo.do(Action.export_your_data):
			export_result = datahub.export_data()
			if export_result != Action.success:
				if export_result == Action.cancel_action:
					print("\nCanceling export data...\n")
				else:
					sys.exit("Issue during update columns! Exiting with status {0} [export_result].".format(export_result))

	if UserWantsTo.do(Action.display_available_queries):	
		datahub.display_queries()

	if UserWantsTo.do(Action.exit_the_api):
		_runApiApp = False
	else:
		datahub.reset_instance_containers_for_new_query()

sys.exit("\n{0}".format("Goodbye!"))
